<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<header class="site-header"><div class="header-inner">
<a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><?php echo dnz_fit_logo_html(); ?><span><?php echo dnz_fit_t('dnz_fit_brand_name', 'span', 'brand-name'); echo dnz_fit_t('dnz_fit_brand_tag', 'span', 'brand-tag'); ?></span></a>
<nav class="nav" aria-label="Ana menü">
<?php if (has_nav_menu('primary')) { wp_nav_menu(array('theme_location'=>'primary','container'=>false,'items_wrap'=>'%3$s')); } else { ?>
<a href="<?php echo esc_url(home_url('/')); ?>">Ana Sayfa</a><a href="<?php echo esc_url(dnz_fit_section_url('dnz_program')); ?>">Dersler</a><a href="<?php echo esc_url(dnz_fit_section_url('dnz_coach')); ?>">Antrenörler</a><a href="<?php echo esc_url(dnz_fit_section_url('dnz_hall')); ?>">Salonlar</a><a href="<?php echo esc_url(home_url('/uyelik/')); ?>">Üyelik</a><a href="<?php echo esc_url(home_url('/rezervasyon/')); ?>">Rezervasyon</a>
<?php } ?>
</nav></div></header>
