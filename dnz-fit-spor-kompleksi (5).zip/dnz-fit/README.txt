DNZ FİT SPOR KOMPLEKSİ — WORDPRESS TEMASI (v3.4.0)
==================================================

KURULUM
1. WordPress yönetim paneline giriş yap.
2. Görünüm > Temalar > Yeni tema ekle > Tema yükle bölümüne gir.
3. Bu ZIP dosyasını seç (bilgisayarında açma). Şimdi yükle > Etkinleştir.
   (Eski sürüm kuruluysa "değiştir" seçeneğini onayla; tema zaten etkinse sayfalar panele ilk girişte otomatik kurulur.)

TEMA ETKİNLEŞİNCE OTOMATİK HAZIRLANANLAR
- Her bölüm için ayrı sayfa oluşturulur (panelde Sayfalar'dan başlığı ve giriş metni düzenlenebilir):
    /antrenorler/      Antrenörler sayfası (tüm antrenörler)
    /dersler/          Dersler sayfası (bireysel ve grup diye ayrılır)
    /spor-salonlari/   Spor Salonları sayfası (basketbol / voleybol diye ayrılır)
    /rezervasyon/      Rezervasyon sayfası
    /uyelik/           Üyelik sayfası
  Listeler, panelden eklediğin antrenör/ders/salonlardan otomatik dolar.
- Not: Ders adresleri /pt-programlari/ yerine /dersler/ oldu; eski adresler otomatik yönlendirilir.
- 3 örnek antrenör, 3 örnek ders, 3 örnek üyelik paketi eklenir ("Örnek" yazılıdır).
- 2 basketbol + 1 voleybol salonu eklenir.
- "DNZ FİT Ana Menü" menüsü oluşturulup Ana Menü konumuna atanır (zaten bir menün varsa dokunulmaz).
- Panelde sarı uyarıdaki "Örnek içerikleri sil" düğmesi örnek antrenör/ders/paketleri tek tıkla siler.
- Kalıcı bağlantılar otomatik yenilenir. Bir sorun olursa Ayarlar > Kalıcı Bağlantılar > Değişiklikleri Kaydet yeterli.

HER ANTRENÖR İÇİN HAZIR SAYFA
Antrenörler > Yeni Antrenör Ekle: ad, fotoğraf (öne çıkan görsel), özgeçmiş metni ve kutudaki alanları (unvan, uzmanlık,
deneyim, sertifikalar, müsait saatler, seans ücreti) doldur. Yayınla; sayfa otomatik oluşur (/antrenorler/ad/):
profil, sertifikalar, verdiği dersler ve o antrenör seçili randevu formu içerir.

HER DERS İÇİN HAZIR SAYFA
Dersler > Yeni Ders Ekle: ad, kapsam metni, fotoğraf ve kutudaki alanları (tür: bireysel/grup, ücret, paket, süre,
gün-saat, seviye, kontenjan, dersi veren antrenörler) doldur. Sayfa otomatik oluşur (/dersler/ders-adi/):
ders bilgileri, antrenörler ve o ders seçili kayıt formu içerir. Dersi bir antrenöre bağlarsan ders o antrenörün sayfasında da görünür.

HER SALON İÇİN HAZIR SAYFA
Spor Salonları: saha bilgisi, kapasite, saatlik ücret, hakem ücreti, çalışma saatleri ve özellikler doldurulur.
Sayfada o salon seçili kiralama formu (hakem talebi dahil) bulunur.

ÜYELİK
Üyelik Paketleri bölümünden paket ekle (fiyat, süre, dahil olanlar, "öne çıkan"). Paketler /uyelik/ sayfasında kart olarak
listelenir; ziyaretçi paketi seçip başvuru formunu gönderir. Sıralamayı paket düzenleme ekranındaki "Sıralama" ile yap.

REZERVASYON VE TALEPLER
- /rezervasyon/ sayfasında talep türü seçilir: antrenörle randevu, ders kaydı veya salon kiralama.
- Gelen tüm rezervasyon ve üyelik talepleri panelde "Talepler" bölümüne kaydedilir (durum: Yeni / Onaylandı / İptal)
  ve ayrıca Ayarlar > Genel'deki yönetici e-postasına gönderilmeye çalışılır. E-posta gitmese bile talep panelde durur.
  E-posta teslimi sunucuya bağlıdır; gerekirse bir SMTP eklentisi kur.
- Bildirim e-postasını değiştirmek için: add_filter('dnz_fit_notify_email', ...) veya Ayarlar > Genel yönetici e-postası.
- ÖNEMLİ: Form bir talep iletir. Salon müsaitlik kontrolü, takvim senkronizasyonu ve kesin onay otomatik DEĞİLDİR;
  ekip talebi arayıp/yazıp manuel onaylamalıdır.
- Formlarda kişisel veri onay kutusu vardır. Yayına almadan önce KVKK aydınlatma metnini sitene eklemeyi unutma.

FOTOĞRAF EKLEME (v3.2)
- Antrenör, ders, salon VE üyelik paketi düzenleme ekranlarında:
    * Ana fotoğraf: sağdaki "Öne çıkan görsel" kutusu (kartlarda ve sayfa başında görünür).
    * Ek fotoğraflar: "Fotoğraf Galerisi" kutusundan "Fotoğraf ekle" ile birden fazla seç, sürükleyerek sırala.
      Antrenör/ders/salon sayfalarında galeri olarak, üyelik paketlerinde kartın içinde küçük resimler olarak görünür; tıklayınca büyür.
- Panel listelerinde (Antrenörler, Dersler...) ilk sütunda küçük fotoğraf görünür.
- Ana sayfa kapak fotoğrafı: Görünüm > Özelleştir > DNZ FİT Ana Sayfa > "Ana sayfa kapak fotoğrafı".

FİYAT SEÇENEKLERİ (v3.2)
- Dersler: ders düzenlemede "Fiyat Seçenekleri" kutusu. "+ Fiyat seçeneği ekle" ile satır ekle (örn. Tek seans 500, 8 seans 3200, 12 seans 4500).
  Ders sayfasında tablo olarak görünür, her satırda "Seç" bağlantısı vardır; kayıt formunda seçilen seçenek talebe eklenir.
  Ders kartlarında "Başlangıç: ... ₺" yazar. Ana "Ücret" alanını boş bırakırsan sadece seçenekler gösterilir.
- Üyelik paketleri: ana fiyatın yanında "Eski fiyat" (indirim için üstü çizili) ve "Fiyat Seçenekleri" (aynı pakete 3 aylık, yıllık vb. ek fiyatlar).
  Paket kartında listelenir; başvuru formunda seçilen süre/fiyat talebe eklenir.

HER ŞEYİ KALEMLE DÜZENLE (v3.3)
- Sitede gez > Özelleştir (veya Görünüm > Özelleştir): önizlemede her yazının/görselin yanında mavi kalem (✎) çıkar.
  Kaleme tıkla, soldaki alanı değiştir; sonuç anında görünür. Sonra "Yayınla"ya bas.
- Değiştirilebilenler: logo + site adı, kapak başlığı/açıklaması/düğmeleri/fotoğrafı, tüm bölüm başlıkları ve açıklamaları,
  4 tesis olanağı (simge, başlık, açıklama, fotoğraf), alt sayfa üst fotoğrafları ve alt kutuları, detay sayfası başlıkları,
  rezervasyon yan kutusu, alt bilgi (telefon/e-posta/adres dahil), vurgu ve koyu renkler.
- Menü: Özelleştir > Menüler (menü öğelerinin yanında da kalem çıkar).
- Antrenör/ders/salon/paket kartlarında ve sayfa başlıklarında, giriş yapmış yöneticiye yeşil kalem görünür; tıklayınca o içeriğin düzenleme ekranı açılır.

SİTEDEN DÜZENLEME (v3.4) — panele girmeden
- WordPress'e giriş yapmış hâlde siteyi gez. Antrenör, ders, salon ve paket kartlarında:
    * 📷 düğmesi: kartın fotoğrafını hemen ekle/değiştir (boş kutucuklara da).
    * ✎ düğmesi: açılan pencerede başlık, açıklama, tüm bilgi alanları, ana fotoğraf, fotoğraf galerisi (saha fotoğrafları),
      fiyat seçenekleri, sıralama ve yayın durumunu düzenle; "Sil" ile kaldır.
    * "＋ Yeni ... ekle" kutusu: yeni antrenör / ders / salon / üyelik paketi ekle.
- Antrenör/ders/salon sayfalarında profil fotoğrafı üstünde 📷, "Fotoğraflar" bölümünde "＋ Fotoğraf ekle" (galeri) bulunur.
- Bu araçlar sadece giriş yapmış yöneticiye görünür; ziyaretçi görmez. Gizlenen (yayında olmayan) içerikler sitede görünmez;
  onları panelde Antrenörler/Dersler/... listesinden açabilirsin.

ÖZELLEŞTİRME
Görünüm > Özelleştir > DNZ FİT Ana Sayfa alanında başlık ve açıklamayı değiştir.
Gerçek fiyatları, fotoğrafları, iletişim bilgilerini ve antrenör profillerini yayınlamadan önce ekle.
