/* DNZ FİT: site içi düzenleme penceresi (sadece giriş yapmış yöneticiler için yüklenir) */
(function ($) {
  var C = window.dnzEdit;
  if (!C || !window.wp || !wp.media) return;

  function post(action, data) {
    return $.post(C.ajax, $.extend({ action: action, nonce: C.nonce }, data));
  }
  function fail(r) { alert((r && r.data) || 'Bir hata oluştu. Lütfen tekrar dene.'); }

  function pick(multiple, cb) {
    var f = wp.media({ title: 'Fotoğraf seç veya yükle', button: { text: multiple ? 'Ekle' : 'Bu fotoğrafı kullan' }, multiple: multiple, library: { type: 'image' } });
    f.on('select', function () { cb(f.state().get('selection').toJSON()); });
    f.open();
  }
  function thumbOf(a) { return (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url; }

  /* --- Karttaki 📷: fotoğrafı hemen değiştir --- */
  $(document).on('click', '[data-dnz-photo]', function (e) {
    e.preventDefault();
    var id = $(this).attr('data-dnz-photo');
    pick(false, function (sel) {
      if (!sel.length) return;
      post('dnz_fit_thumb', { id: id, att: sel[0].id }).done(function (r) { r.success ? location.reload() : fail(r); }).fail(fail);
    });
  });

  /* --- Sayfadaki "＋ Fotoğraf ekle": galeriye ekle --- */
  $(document).on('click', '[data-dnz-gallery]', function (e) {
    e.preventDefault();
    var id = $(this).attr('data-dnz-gallery');
    pick(true, function (sel) {
      if (!sel.length) return;
      post('dnz_fit_gallery_add', { id: id, atts: sel.map(function (a) { return a.id; }).join(',') })
        .done(function (r) { r.success ? location.reload() : fail(r); }).fail(fail);
    });
  });

  /* --- ✎ ve ＋ Yeni ekle: düzenleme penceresi --- */
  $(document).on('click', '[data-dnz-edit]', function (e) { e.preventDefault(); openEditor({ id: $(this).attr('data-dnz-edit') }); });
  $(document).on('click', '[data-dnz-new]', function (e) { e.preventDefault(); openEditor({ type: $(this).attr('data-dnz-new'), id: 0 }); });

  function field(label, $input, hint) {
    var $r = $('<div class="dnz-row"></div>').append($('<label></label>').text(label)).append($input);
    if (hint) $r.append($('<small></small>').text(hint));
    return $r;
  }

  function openEditor(req) {
    var $m = $('<div class="dnz-modal" role="dialog" aria-modal="true"><div class="dnz-box"><div class="dnz-head"><h3>Yükleniyor…</h3><button type="button" class="dnz-x" aria-label="Kapat">×</button></div><form class="dnz-body"></form><div class="dnz-foot"></div></div></div>').appendTo('body');
    $('body').addClass('dnz-modal-open');
    function close() { $m.remove(); $('body').removeClass('dnz-modal-open'); $(document).off('keydown.dnz'); }
    $m.on('click', '.dnz-x', close);
    $(document).on('keydown.dnz', function (e) { if (e.key === 'Escape' && !$('.media-modal:visible').length) close(); });

    post('dnz_fit_load', req).done(function (r) {
      if (!r.success) { close(); return fail(r); }
      build($m, r.data, close);
    }).fail(function (x) { close(); fail(x); });
  }

  function build($m, d, close) {
    var $f = $m.find('.dnz-body').empty(), $foot = $m.find('.dnz-foot').empty();
    $m.find('h3').text(d.id ? d.typeLabel + ' düzenle' : 'Yeni ' + d.typeLabel.toLowerCase() + ' ekle');

    $f.append(field('Başlık / ad *', $('<input type="text" name="title" required>').val(d.title)));

    /* Ana fotoğraf */
    var $thumbInput = $('<input type="hidden" name="thumb_id">').val(d.thumb ? d.thumb.id : '');
    var $prev = $('<div class="dnz-thumb"></div>');
    function showThumb(url) { $prev.empty(); if (url) $prev.append($('<img alt="">').attr('src', url)); else $prev.text('Fotoğraf yok'); }
    showThumb(d.thumb && d.thumb.url);
    var $photo = $('<div class="dnz-photo"></div>').append($prev, $('<div class="dnz-photo-btns"></div>').append(
      $('<button type="button" class="dnz-btn">Fotoğraf seç / yükle</button>').on('click', function () {
        pick(false, function (s) { if (s.length) { $thumbInput.val(s[0].id); showThumb(thumbOf(s[0])); } });
      }),
      $('<button type="button" class="dnz-btn ghost">Kaldır</button>').on('click', function () { $thumbInput.val(''); showThumb(''); })
    ), $thumbInput);
    $f.append(field('Ana fotoğraf (kartta ve sayfa başında görünür)', $photo));

    $f.append(field('Kısa açıklama (kartta görünür)', $('<textarea name="excerpt" rows="2"></textarea>').val(d.excerpt)));
    if (d.hasContent) $f.append(field('Detaylı açıklama / özgeçmiş (sayfada görünür)', $('<textarea name="content" rows="5"></textarea>').val(d.content)));

    /* Alanlar */
    $.each(d.fields, function (_, o) {
      var name = 'f[' + o.key + ']', $in;
      if (o.type === 'textarea') $in = $('<textarea rows="3"></textarea>').attr('name', name).val(o.value);
      else if (o.type === 'select') {
        $in = $('<select></select>').attr('name', name);
        $.each(o.options, function (_, op) { $in.append($('<option></option>').text(op).prop('selected', op === o.value)); });
      } else if (o.type === 'checkbox') {
        $in = $('<label class="dnz-check"></label>').append($('<input type="checkbox" value="1">').attr('name', name).prop('checked', !!o.value), document.createTextNode(' ' + (o.hint || 'Evet')));
        $f.append($('<div class="dnz-row"></div>').append($in)); return;
      } else if (o.type === 'coaches') {
        $in = $('<div class="dnz-checks"></div>');
        if (!o.options.length) $in.text('Önce antrenör ekle.');
        $.each(o.options, function (_, c) {
          $in.append($('<label class="dnz-check"></label>').append($('<input type="checkbox">').attr({ name: name + '[]', value: c.id }).prop('checked', $.inArray(c.id, o.value) > -1), document.createTextNode(' ' + c.title)));
        });
      } else $in = $('<input>').attr({ type: o.type === 'number' ? 'number' : 'text', name: name, min: o.type === 'number' ? 0 : null }).val(o.value);
      $f.append(field(o.label, $in, o.type === 'select' || o.type === 'coaches' ? '' : o.hint));
    });

    /* Fiyat seçenekleri */
    if (d.hasPrices) {
      var $tb = $('<tbody></tbody>'), n = 0;
      function addRow(l, p) {
        var i = n++;
        $tb.append($('<tr></tr>').append(
          $('<td></td>').append($('<input type="text" placeholder="Seçenek adı (örn: 8 seans)">').attr('name', 'prices[' + i + '][label]').val(l)),
          $('<td></td>').append($('<input type="text" placeholder="Fiyat (örn: 3200)">').attr('name', 'prices[' + i + '][price]').val(p)),
          $('<td></td>').append($('<button type="button" class="dnz-rm" aria-label="Sil">×</button>').on('click', function () { $(this).closest('tr').remove(); }))));
      }
      $.each(d.prices, function (_, r) { addRow(r.label, r.price); });
      var $pt = $('<div></div>').append($('<table class="dnz-prices"></table>').append($tb),
        $('<button type="button" class="dnz-btn ghost">＋ Fiyat seçeneği ekle</button>').on('click', function () { addRow('', ''); }));
      $f.append(field('Fiyat seçenekleri', $pt, d.pricesHint));
    }

    /* Galeri */
    var $gal = $('<ul class="dnz-gal"></ul>'), $galInput = $('<input type="hidden" name="gallery">');
    function syncGal() { $galInput.val($gal.children().map(function () { return $(this).attr('data-id'); }).get().join(',')); }
    function addGal(id, url) {
      if ($gal.children('[data-id="' + id + '"]').length) return;
      $gal.append($('<li></li>').attr('data-id', id).append($('<img alt="">').attr('src', url), $('<button type="button" class="dnz-rm" aria-label="Kaldır">×</button>').on('click', function () { $(this).closest('li').remove(); syncGal(); })));
    }
    $.each(d.gallery, function (_, g) { addGal(g.id, g.url); });
    syncGal();
    if ($.fn.sortable) $gal.sortable({ update: syncGal });
    $f.append(field('Fotoğraf galerisi (saha / salon / ek fotoğraflar)', $('<div></div>').append($gal, $galInput,
      $('<button type="button" class="dnz-btn">＋ Fotoğraf ekle</button>').on('click', function () {
        pick(true, function (s) { $.each(s, function (_, a) { addGal(a.id, thumbOf(a)); }); syncGal(); });
      })), 'Sürükleyerek sıralayabilirsin.'));

    $f.append(field('Sıralama (küçük sayı önce görünür)', $('<input type="number" name="order" min="0">').val(d.order)));
    $f.append($('<div class="dnz-row"></div>').append($('<label class="dnz-check"></label>').append($('<input type="checkbox" name="published" value="1">').prop('checked', d.published), document.createTextNode(' Sitede yayında (işareti kaldırırsan gizlenir)'))));

    /* Alt düğmeler */
    var $msg = $('<span class="dnz-msg"></span>');
    var $save = $('<button type="button" class="dnz-btn primary">Kaydet</button>').on('click', function () {
      if (!$f[0].checkValidity()) { $f[0].reportValidity(); return; }
      $save.prop('disabled', true).text('Kaydediliyor…');
      $.post(C.ajax, $f.serialize() + '&' + $.param({ action: 'dnz_fit_save', nonce: C.nonce, id: d.id, type: d.type }))
        .done(function (r) { if (r.success) location.reload(); else { fail(r); $save.prop('disabled', false).text('Kaydet'); } })
        .fail(function (x) { fail(x); $save.prop('disabled', false).text('Kaydet'); });
    });
    $foot.append($save, $('<button type="button" class="dnz-btn ghost">Vazgeç</button>').on('click', close));
    if (d.id) {
      $foot.append($('<button type="button" class="dnz-btn danger">Sil</button>').on('click', function () {
        if (!confirm('Bu içerik silinsin mi? (Çöp kutusuna taşınır)')) return;
        post('dnz_fit_delete', { id: d.id }).done(function (r) {
          if (!r.success) return fail(r);
          if (String(C.current) === String(d.id)) location.href = r.data.section; else location.reload();
        }).fail(fail);
      }));
    }
    $foot.append($msg);
  }
})(jQuery);
