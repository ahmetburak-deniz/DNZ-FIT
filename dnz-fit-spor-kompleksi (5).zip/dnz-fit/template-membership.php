<?php
/* Template Name: Üyelik Sayfası */
get_header(); ?>
<section class="page-hero"><?php echo dnz_fit_img_box('dnz_fit_img_membership'); ?><div class="wrap">
  <?php echo dnz_fit_t('dnz_fit_page_membership_eyebrow', 'div', 'eyebrow'); ?>
  <?php echo dnz_fit_t('dnz_fit_page_membership_title', 'h1'); ?>
  <?php echo dnz_fit_t('dnz_fit_page_membership_text', 'p'); ?>
</div></section>
<main class="wrap section"><?php while (have_posts()) : the_post(); the_content(); endwhile; ?></main>
<?php get_footer(); ?>
