<?php
if (!defined('ABSPATH')) exit;

/* =========================================================
   FOTOĞRAF GALERİSİ (antrenör, ders, salon, üyelik paketi)
   FİYAT SEÇENEKLERİ (ders, üyelik paketi)
   ========================================================= */

function dnz_fit_gallery_types() { return array('dnz_coach', 'dnz_program', 'dnz_hall', 'dnz_plan'); }
function dnz_fit_price_types()   { return array('dnz_program', 'dnz_plan'); }

/* ---------- Veri yardımcıları ---------- */
function dnz_fit_gallery_ids($post_id) {
    $ids = get_post_meta($post_id, '_dnz_gallery', true);
    $out = array();
    if (is_array($ids)) foreach ($ids as $i) {
        $i = absint($i);
        if ($i && wp_attachment_is_image($i)) $out[] = $i;
    }
    return $out;
}

/* Ek fiyat satırları: array(array('label' => '8 seans', 'price' => '3200'), ...) */
function dnz_fit_price_rows($post_id) {
    $rows = get_post_meta($post_id, '_dnz_prices', true);
    $out = array();
    if (is_array($rows)) foreach ($rows as $r) {
        if (!is_array($r)) continue;
        $l = isset($r['label']) ? trim((string) $r['label']) : '';
        $p = isset($r['price']) ? trim((string) $r['price']) : '';
        if ($l === '' && $p === '') continue;
        $out[] = array('label' => $l, 'price' => $p);
    }
    return $out;
}

/* "Etiket — 3.200 ₺" */
function dnz_fit_price_row_text($row) {
    return ($row['label'] !== '' ? $row['label'] . ' — ' : '') . dnz_fit_money($row['price']);
}

/* Kartlarda "başlangıç fiyatı": ana fiyat + ek seçeneklerin en düşüğü (sadece sayısal olanlar) */
function dnz_fit_lowest_price($post_id) {
    $vals = array();
    $cands = array(dnz_fit_meta($post_id, 'price'));
    foreach (dnz_fit_price_rows($post_id) as $r) $cands[] = $r['price'];
    foreach ($cands as $c) {
        $c = trim((string) $c);
        if (preg_match('/^\d+([.,]\d+)?$/', $c)) $vals[] = (float) str_replace(',', '.', $c);
    }
    return $vals ? (string) min($vals) : '';
}

/* ---------- Yönetim paneli ---------- */
function dnz_fit_media_meta_boxes() {
    foreach (dnz_fit_price_types() as $pt) {
        add_meta_box('dnz_prices', 'Fiyat Seçenekleri', 'dnz_fit_render_prices_box', $pt, 'normal', 'high');
    }
    foreach (dnz_fit_gallery_types() as $pt) {
        add_meta_box('dnz_gallery', 'Fotoğraf Galerisi', 'dnz_fit_render_gallery_box', $pt, 'normal', 'default');
    }
}
add_action('add_meta_boxes', 'dnz_fit_media_meta_boxes');

function dnz_fit_render_gallery_box($post) {
    wp_nonce_field('dnz_fit_media', 'dnz_fit_media_nonce');
    $ids = dnz_fit_gallery_ids($post->ID);
    echo '<p class="description">Ana fotoğraf için sağ taraftaki <strong>Öne çıkan görsel</strong> kutusunu kullan. Buraya ek fotoğraflar ekle; sürükleyerek sıralayabilirsin.</p>';
    echo '<ul id="dnz-gallery-list">';
    foreach ($ids as $id) {
        echo '<li data-id="' . (int) $id . '">' . wp_get_attachment_image($id, 'thumbnail') . '<button type="button" class="dnz-gal-remove" aria-label="Kaldır">×</button></li>';
    }
    echo '</ul>';
    echo '<input type="hidden" id="dnz-gallery-input" name="dnz_gallery" value="' . esc_attr(implode(',', $ids)) . '">';
    echo '<button type="button" class="button" id="dnz-gallery-add">Fotoğraf ekle</button>';
}

function dnz_fit_render_prices_box($post) {
    $rows = dnz_fit_price_rows($post->ID);
    $is_plan = $post->post_type === 'dnz_plan';
    echo '<p class="description">' . ($is_plan
        ? 'Ana fiyat yukarıdaki “Fiyat” alanıdır. Aynı pakete farklı süre/fiyat seçenekleri eklemek istersen buraya ekle. Örn: <em>3 Aylık</em> → <em>4000</em>.'
        : 'Ana ücret yukarıdaki “Ücret” alanıdır. Birden fazla fiyat seçeneği sunmak istersen buraya ekle. Örn: <em>Tek seans</em> → <em>500</em>, <em>8 seans</em> → <em>3200</em>.') . ' Fiyat boş bırakılırsa “Fiyat için iletişime geçin” yazar.</p>';
    echo '<table class="widefat striped" id="dnz-price-table"><thead><tr><th>Seçenek adı</th><th>Fiyat (₺)</th><th style="width:60px"></th></tr></thead><tbody>';
    foreach ($rows as $i => $r) {
        echo dnz_fit_price_row_html($i, $r['label'], $r['price']);
    }
    echo '</tbody></table>';
    echo '<p><button type="button" class="button" id="dnz-price-add">+ Fiyat seçeneği ekle</button></p>';
    echo '<script type="text/template" id="dnz-price-tpl">' . dnz_fit_price_row_html('__i__', '', '') . '</script>';
}

function dnz_fit_price_row_html($i, $label, $price) {
    return '<tr><td><input type="text" class="widefat" name="dnz_prices[' . esc_attr($i) . '][label]" value="' . esc_attr($label) . '" placeholder="Örn: 8 seans"></td>'
        . '<td><input type="text" class="widefat" name="dnz_prices[' . esc_attr($i) . '][price]" value="' . esc_attr($price) . '" placeholder="Örn: 3200"></td>'
        . '<td><button type="button" class="button-link-delete dnz-price-remove">Sil</button></td></tr>';
}

function dnz_fit_media_admin_assets($hook) {
    if (!in_array($hook, array('post.php', 'post-new.php'), true)) return;
    $screen = get_current_screen();
    if (!$screen || !in_array($screen->post_type, dnz_fit_gallery_types(), true)) return;

    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');

    wp_add_inline_style('common', '
        #dnz-gallery-list{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0;padding:0;list-style:none}
        #dnz-gallery-list li{position:relative;cursor:move}
        #dnz-gallery-list img{width:100px;height:100px;object-fit:cover;border-radius:6px;display:block}
        .dnz-gal-remove{position:absolute;top:3px;right:3px;width:22px;height:22px;border:0;border-radius:50%;background:#fff;color:#b32d2e;font-size:16px;line-height:20px;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.3)}
    ');

    $js = <<<'JS'
jQuery(function($){
  var list=$('#dnz-gallery-list'), input=$('#dnz-gallery-input'), frame;
  if(list.length){
    var sync=function(){input.val(list.children().map(function(){return $(this).attr('data-id');}).get().join(','));};
    list.sortable({update:sync});
    list.on('click','.dnz-gal-remove',function(){$(this).closest('li').remove();sync();});
    $('#dnz-gallery-add').on('click',function(e){
      e.preventDefault();
      if(!frame){
        frame=wp.media({title:'Fotoğraf seç',button:{text:'Galeriye ekle'},multiple:true,library:{type:'image'}});
        frame.on('select',function(){
          frame.state().get('selection').each(function(a){
            a=a.toJSON();
            if(list.children('[data-id="'+a.id+'"]').length) return;
            var u=(a.sizes&&a.sizes.thumbnail)?a.sizes.thumbnail.url:a.url;
            var li=$('<li></li>').attr('data-id',a.id);
            li.append($('<img>').attr('src',u)).append('<button type="button" class="dnz-gal-remove" aria-label="Kaldır">×</button>');
            list.append(li);
          });
          sync();
        });
      }
      frame.open();
    });
  }
  var tb=$('#dnz-price-table tbody'), n=tb.children().length+100;
  $('#dnz-price-add').on('click',function(){
    tb.append($('#dnz-price-tpl').html().replace(/__i__/g,n++));
  });
  tb.on('click','.dnz-price-remove',function(){$(this).closest('tr').remove();});
});
JS;
    wp_add_inline_script('jquery-ui-sortable', $js);
}
add_action('admin_enqueue_scripts', 'dnz_fit_media_admin_assets');

function dnz_fit_save_media($post_id, $post) {
    if (!isset($_POST['dnz_fit_media_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnz_fit_media_nonce'])), 'dnz_fit_media')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    $raw = isset($_POST['dnz_gallery']) && is_scalar($_POST['dnz_gallery']) ? sanitize_text_field(wp_unslash($_POST['dnz_gallery'])) : '';
    $prices = (isset($_POST['dnz_prices']) && is_array($_POST['dnz_prices'])) ? wp_unslash($_POST['dnz_prices']) : array();
    dnz_fit_apply_media($post_id, $post->post_type, $raw, $prices);
}

/* Galeri (virgüllü kimlik listesi) ve fiyat satırlarını temizleyip kaydeder */
function dnz_fit_apply_media($post_id, $pt, $gallery_csv, $prices_in) {
    if (in_array($pt, dnz_fit_gallery_types(), true)) {
        $ids = array();
        foreach (explode(',', (string) $gallery_csv) as $i) {
            $i = absint($i);
            if ($i && wp_attachment_is_image($i) && !in_array($i, $ids, true)) $ids[] = $i;
        }
        update_post_meta($post_id, '_dnz_gallery', $ids);
    }
    if (in_array($pt, dnz_fit_price_types(), true)) {
        $rows = array();
        foreach ((array) $prices_in as $r) {
            if (!is_array($r)) continue;
            $l = sanitize_text_field(isset($r['label']) && is_scalar($r['label']) ? $r['label'] : '');
            $p = sanitize_text_field(isset($r['price']) && is_scalar($r['price']) ? $r['price'] : '');
            if ($l === '' && $p === '') continue;
            $rows[] = array('label' => $l, 'price' => $p);
            if (count($rows) >= 20) break;
        }
        update_post_meta($post_id, '_dnz_prices', $rows);
    }
}
add_action('save_post', 'dnz_fit_save_media', 10, 2);

/* Panel listelerinde küçük fotoğraf sütunu */
function dnz_fit_admin_thumb_columns() {
    foreach (dnz_fit_gallery_types() as $pt) {
        add_filter('manage_' . $pt . '_posts_columns', function ($cols) {
            return array_merge(array('cb' => isset($cols['cb']) ? $cols['cb'] : '', 'dnz_thumb' => 'Fotoğraf'), array_diff_key($cols, array('cb' => 1)));
        });
        add_action('manage_' . $pt . '_posts_custom_column', function ($col, $id) {
            if ($col !== 'dnz_thumb') return;
            echo has_post_thumbnail($id) ? get_the_post_thumbnail($id, array(60, 60), array('style' => 'width:60px;height:60px;object-fit:cover;border-radius:6px')) : '—';
        }, 10, 2);
    }
}
add_action('admin_init', 'dnz_fit_admin_thumb_columns');

/* ---------- Site görünümü ---------- */

/* Galeri: tıklayınca büyüyen fotoğraflar */
function dnz_fit_gallery($post_id, $title = 'Fotoğraflar') {
    $ids = dnz_fit_gallery_ids($post_id);
    $btn = ($title !== '' && dnz_fit_frontend_edit() && current_user_can('edit_post', $post_id))
        ? '<p><button type="button" class="dnz-gal-add" data-dnz-gallery="' . (int) $post_id . '">＋ Fotoğraf ekle</button></p>' : '';
    if (!$ids) return $btn ? '<h2>' . esc_html($title) . '</h2>' . $btn : '';
    $GLOBALS['dnz_fit_lightbox'] = true;
    $h = ($title !== '' ? '<h2>' . esc_html($title) . '</h2>' : '') . '<div class="gallery-grid">';
    foreach ($ids as $id) {
        $h .= '<a href="' . esc_url(wp_get_attachment_image_url($id, 'full')) . '" data-lightbox>' . wp_get_attachment_image($id, 'medium_large', false, array('loading' => 'lazy')) . '</a>';
    }
    return $h . '</div>' . $btn;
}

function dnz_fit_lightbox_script() {
    if (empty($GLOBALS['dnz_fit_lightbox'])) return;
    ?>
    <script>
    (function(){document.addEventListener('click',function(e){
      var a=e.target.closest&&e.target.closest('[data-lightbox]');if(!a)return;e.preventDefault();
      var o=document.createElement('div');o.className='lightbox';var im=document.createElement('img');im.src=a.href;im.alt='';o.appendChild(im);
      function k(ev){if(ev.key==='Escape')x();}
      function x(){o.remove();document.removeEventListener('keydown',k);}
      o.addEventListener('click',x);document.addEventListener('keydown',k);document.body.appendChild(o);
    });})();
    </script>
    <?php
}
add_action('wp_footer', 'dnz_fit_lightbox_script');

/* Ders sayfasındaki fiyat seçenekleri tablosu (her satırda "Seç" bağlantısı) */
function dnz_fit_price_table($post_id, $select_url = '') {
    $rows = dnz_fit_price_rows($post_id);
    if (!$rows) return '';
    $h = '<div class="info-card price-table"><h3>Fiyat seçenekleri</h3><ul class="info-list">';
    foreach ($rows as $i => $r) {
        $h .= '<li><span>' . esc_html($r['label']) . '</span><b>' . esc_html(dnz_fit_money($r['price']));
        if ($select_url) $h .= ' <a class="mini-link" href="' . esc_url(add_query_arg('pkg', $i, $select_url) . '#talep') . '">Seç</a>';
        $h .= '</b></li>';
    }
    return $h . '</ul></div>';
}

/* Üyelik paketi kartı (ana sayfa ve üyelik sayfası için ortak) */
function dnz_fit_plan_card($p, $page_url) {
    $id   = $p->ID;
    $feat = dnz_fit_meta($id, 'featured') === '1';
    $h  = '<article class="plan' . ($feat ? ' featured' : '') . '">' . dnz_fit_edit_link($id);
    if (has_post_thumbnail($id)) $h .= '<div class="plan-photo">' . get_the_post_thumbnail($id, 'medium_large') . '</div>';
    if ($period = dnz_fit_meta($id, 'period')) $h .= '<span class="pill">' . esc_html($period) . ($feat ? ' · Öne çıkan' : '') . '</span>';
    $h .= '<h3>' . esc_html(get_the_title($p)) . '</h3>';
    $h .= '<div class="price">';
    if ($old = dnz_fit_meta($id, 'old_price')) $h .= '<s class="old-price">' . esc_html(dnz_fit_money($old)) . '</s> ';
    $h .= esc_html(dnz_fit_money(dnz_fit_meta($id, 'price'))) . '</div>';
    if ($p->post_excerpt) $h .= '<p>' . esc_html($p->post_excerpt) . '</p>';
    if ($rows = dnz_fit_price_rows($id)) {
        $h .= '<ul class="plan-options">';
        foreach ($rows as $i => $r) {
            $h .= '<li><span>' . esc_html($r['label']) . '</span><b>' . esc_html(dnz_fit_money($r['price'])) . '</b> <a class="mini-link" href="' . esc_url(add_query_arg(array('plan' => $id, 'opt' => $i), $page_url) . '#uyelik-formu') . '">Seç</a></li>';
        }
        $h .= '</ul>';
    }
    $lines = dnz_fit_lines(dnz_fit_meta($id, 'features'));
    if ($lines) { $h .= '<ul class="check-list">'; foreach ($lines as $l) $h .= '<li>' . esc_html($l) . '</li>'; $h .= '</ul>'; }
    $gal = dnz_fit_gallery($id, '');
    if ($gal) $h .= '<div class="plan-gallery">' . $gal . '</div>';
    $h .= '<a class="btn" href="' . esc_url(add_query_arg('plan', $id, $page_url) . '#uyelik-formu') . '">Bu paketi seç</a>';
    return $h . '</article>';
}
