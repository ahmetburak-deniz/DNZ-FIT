<?php
if (!defined('ABSPATH')) exit;

/* =========================================================
   TÜM YAZI VE GÖRSELLER: Görünüm > Özelleştir
   Önizlemede her yazının/görselin yanında kalem (✎) çıkar;
   tıklayınca ilgili alan açılır ve değişiklik anında görünür.
   ========================================================= */

/* alan: id => array(etiket, varsayılan, tür [text|textarea|image|color], seçenekler) */
function dnz_fit_defs() {
    static $d = null;
    if ($d !== null) return $d;
    $band = 'Talebini gönder, ekibimiz müsaitliği teyit edip seninle iletişime geçsin.';
    $S = array();

    $S['dnz_fit_home'] = array('DNZ FİT Ana Sayfa – Kapak', array(
        'dnz_fit_hero_eyebrow' => array('Kapak: küçük üst yazı', 'DNZ FİT Spor Kompleksi', 'text'),
        'dnz_fit_hero_title'   => array('Kapak: ana başlık', "GÜCÜNÜ\nKEŞFET.", 'textarea'),
        'dnz_fit_hero_text'    => array('Kapak: açıklama', 'Spor kompleksimizde PT eğitimleri, salon kiralama ve üyelik seçenekleriyle hedeflerine yaklaş.', 'textarea'),
        'dnz_fit_hero_btn1'    => array('Kapak: 1. düğme yazısı', 'Randevu / Rezervasyon talebi ↗', 'text'),
        'dnz_fit_hero_btn2'    => array('Kapak: 2. düğme yazısı', 'Üyelik paketleri', 'text'),
        'dnz_fit_hero_image'   => array('Kapak fotoğrafı', '', 'image', array('render' => 'dnz_fit_hero_graphic')),
        'dnz_fit_hero_big'     => array('Kapak: büyük yazı (fotoğraf yoksa)', 'DNZ', 'text'),
        'dnz_fit_hero_small'   => array('Kapak: alt yazı', 'TRAIN • FOCUS • REPEAT', 'text'),
    ));

    $S['dnz_sec_brand'] = array('Logo ve Üst Menü', array(
        'dnz_fit_logo'        => array('Logo görseli (boşsa harf kutusu görünür)', '', 'image', array('render' => 'dnz_fit_logo_html')),
        'dnz_fit_logo_letter' => array('Logo harfi', 'F', 'text'),
        'dnz_fit_brand_name'  => array('Site adı', 'DNZ FİT', 'text'),
        'dnz_fit_brand_tag'   => array('Site alt yazısı', 'SPOR KOMPLEKSİ • PT • SALON KİRALAMA', 'text'),
    ));

    $S['dnz_sec_home_programs'] = array('Ana Sayfa – Dersler bölümü', dnz_fit_head_defs('home_programs', 'Kişisel hedeflerin', 'DERSLER & PT EĞİTİMLERİ', 'Bireysel veya grup dersini seç; ücret, gün, saat ve kapsam bilgilerini ders sayfasında gör, oradan kayıt talep et.') + array(
        'dnz_fit_home_programs_btn' => array('Düğme yazısı', 'Tüm dersler', 'text'),
    ));
    $S['dnz_sec_home_coaches'] = array('Ana Sayfa – Antrenörler bölümü', dnz_fit_head_defs('home_coaches', 'Ekibimiz', 'ANTRENÖRLER', 'Her antrenörün kendi sayfasında uzmanlık alanı, özgeçmiş, sertifikalar ve randevu formu yer alır.') + array(
        'dnz_fit_home_coaches_btn' => array('Düğme yazısı', 'Tüm antrenörler', 'text'),
    ));
    $S['dnz_sec_home_halls'] = array('Ana Sayfa – Salonlar bölümü', dnz_fit_head_defs('home_halls', 'Salon ve kiralama', 'SAHA REZERVASYONU', 'Komplekste 2 adet basketbol sahası ve 1 adet voleybol sahası için rezervasyon talebi oluştur. Hakem hizmeti talebini formda belirtebilirsin.') + array(
        'dnz_fit_home_halls_btn' => array('Düğme yazısı', 'Salon rezervasyonu talep et ↗', 'text'),
    ));

    $fac = dnz_fit_head_defs('home_facility', 'Kompleks olanakları', 'TESİS OLANAKLARI', 'Spor deneyimini destekleyen alanlar ve üyelik işlemleri tek yerde.');
    $feats = array(
        1 => array('🚿', 'Duş & Soyunma Odası', 'Üyelerin kullanımına yönelik tesis alanları.'),
        2 => array('🅿️', 'Otopark', 'Tesis ziyaretçileri için otopark bilgisi.'),
        3 => array('☕', 'Kafe', 'Dinlenme ve buluşma alanı.'),
        4 => array('🎟️', 'Üyelik İşlemleri', 'Üyelik ve paket başvurusunu online yap.'),
    );
    foreach ($feats as $n => $f) {
        $fac['dnz_fit_feat' . $n . '_img']   = array($n . '. olanak: fotoğraf (isteğe bağlı)', '', 'image', array('class' => 'feature-img'));
        $fac['dnz_fit_feat' . $n . '_icon']  = array($n . '. olanak: simge/emoji', $f[0], 'text');
        $fac['dnz_fit_feat' . $n . '_title'] = array($n . '. olanak: başlık', $f[1], 'text');
        $fac['dnz_fit_feat' . $n . '_desc']  = array($n . '. olanak: açıklama', $f[2], 'text');
    }
    $S['dnz_sec_home_facility'] = array('Ana Sayfa – Tesis olanakları', $fac);

    $S['dnz_sec_home_plans'] = array('Ana Sayfa – Üyelik bölümü', dnz_fit_head_defs('home_plans', 'Üyelik', 'ÜYELİK PAKETLERİ', 'Sana uygun paketi seç ve online başvurunu bırak.') + array(
        'dnz_fit_home_plans_band_title' => array('Renkli kutu: başlık', 'HEDEFİNİ BELİRLE. HAREKETE GEÇ.', 'text'),
        'dnz_fit_contact_text'          => array('Renkli kutu: açıklama', 'Rezervasyon ve üyelik taleplerin için formu doldur; ekibimiz seninle iletişime geçsin.', 'textarea'),
        'dnz_fit_home_plans_band_btn'   => array('Renkli kutu: düğme yazısı', 'Üye ol ↗', 'text'),
    ));
    $S['dnz_sec_home_blog'] = array('Ana Sayfa – Duyurular bölümü', dnz_fit_head_defs('home_blog', 'Blog & duyurular', 'SON DUYURULAR', 'Salon duyurularını, etkinlikleri ve spor yazılarını WordPress Yazılar bölümünden yayınla.'));

    $S['dnz_sec_page_coaches'] = array('Sayfa – Antrenörler', array(
        'dnz_fit_img_coaches'        => array('Sayfa üst görseli', '', 'image', array('class' => 'page-hero-bg')),
        'dnz_fit_page_coaches_eyebrow' => array('Üst küçük yazı', 'Ekibimiz', 'text'),
        'dnz_fit_page_coaches_band_title' => array('Alt kutu: başlık', 'Antrenörünle randevu al', 'text'),
        'dnz_fit_page_coaches_band_text'  => array('Alt kutu: açıklama', $band, 'textarea'),
        'dnz_fit_page_coaches_band_btn'   => array('Alt kutu: düğme', 'Randevu talep et ↗', 'text'),
    ));
    $S['dnz_sec_page_programs'] = array('Sayfa – Dersler', array(
        'dnz_fit_img_programs'        => array('Sayfa üst görseli', '', 'image', array('class' => 'page-hero-bg')),
        'dnz_fit_page_programs_eyebrow' => array('Üst küçük yazı', 'Dersler & PT', 'text'),
        'dnz_fit_page_programs_band_title' => array('Alt kutu: başlık', 'Bir derse kaydol', 'text'),
        'dnz_fit_page_programs_band_text'  => array('Alt kutu: açıklama', $band, 'textarea'),
        'dnz_fit_page_programs_band_btn'   => array('Alt kutu: düğme', 'Ders kaydı talep et ↗', 'text'),
    ));
    $S['dnz_sec_page_halls'] = array('Sayfa – Spor Salonları', array(
        'dnz_fit_img_halls'        => array('Sayfa üst görseli', '', 'image', array('class' => 'page-hero-bg')),
        'dnz_fit_page_halls_eyebrow' => array('Üst küçük yazı', 'Salon ve kiralama', 'text'),
        'dnz_fit_page_halls_band_title' => array('Alt kutu: başlık', 'Salon kiralamak mı istiyorsun?', 'text'),
        'dnz_fit_page_halls_band_text'  => array('Alt kutu: açıklama', $band, 'textarea'),
        'dnz_fit_page_halls_band_btn'   => array('Alt kutu: düğme', 'Salon talep et ↗', 'text'),
    ));
    $S['dnz_sec_page_membership'] = array('Sayfa – Üyelik', array(
        'dnz_fit_img_membership'      => array('Sayfa üst görseli', '', 'image', array('class' => 'page-hero-bg')),
        'dnz_fit_page_membership_eyebrow' => array('Üst küçük yazı', 'Üyelik', 'text'),
        'dnz_fit_page_membership_title'   => array('Başlık', 'DNZ FİT üyelik paketleri', 'text'),
        'dnz_fit_page_membership_text'    => array('Açıklama', 'Sana uygun paketi seç, başvurunu gönder; ekibimiz üyelik işlemlerini tamamlamak için seninle iletişime geçsin.', 'textarea'),
    ));
    $S['dnz_sec_page_res'] = array('Sayfa – Rezervasyon', array(
        'dnz_fit_img_res'          => array('Sayfa üst görseli', '', 'image', array('class' => 'page-hero-bg')),
        'dnz_fit_page_res_eyebrow' => array('Üst küçük yazı', 'Rezervasyon', 'text'),
        'dnz_fit_page_res_title'   => array('Başlık', 'Randevu ve salon rezervasyonu', 'text'),
        'dnz_fit_page_res_text'    => array('Açıklama', 'Antrenörle randevu, ders kaydı veya salon kiralama için talebini gönder; ekibimiz müsaitliği teyit edip seninle iletişime geçsin.', 'textarea'),
        'dnz_fit_res_side_title'   => array('Yan kutu: başlık', 'Nasıl çalışır?', 'text'),
        'dnz_fit_res_step1'        => array('Yan kutu: 1. adım', 'Talep türünü seç ve formu doldur.', 'text'),
        'dnz_fit_res_step2'        => array('Yan kutu: 2. adım', 'Ekibimiz müsaitliği kontrol eder.', 'text'),
        'dnz_fit_res_step3'        => array('Yan kutu: 3. adım', 'Seni arayıp rezervasyonu onaylar.', 'text'),
    ));

    $S['dnz_sec_single'] = array('Antrenör / Ders / Salon sayfaları', array(
        'dnz_fit_coach_eyebrow'  => array('Antrenör sayfası: üst küçük yazı', 'Antrenör Profili', 'text'),
        'dnz_fit_coach_about'    => array('Antrenör: “Hakkında” başlığı', 'Hakkında', 'text'),
        'dnz_fit_coach_certs'    => array('Antrenör: sertifikalar başlığı', 'Sertifikalar ve belgeler', 'text'),
        'dnz_fit_coach_programs' => array('Antrenör: verdiği dersler başlığı', 'Verdiği dersler', 'text'),
        'dnz_fit_coach_btn'      => array('Antrenör: randevu düğmesi', 'Bu antrenörden randevu al ↗', 'text'),
        'dnz_fit_program_about'  => array('Ders: kapsam başlığı', 'Ders kapsamı', 'text'),
        'dnz_fit_program_coaches' => array('Ders: antrenörler başlığı', 'Dersi veren antrenörler', 'text'),
        'dnz_fit_program_btn'    => array('Ders: kayıt düğmesi', 'Bu derse kayıt talep et ↗', 'text'),
        'dnz_fit_hall_about'     => array('Salon: hakkında başlığı', 'Salon hakkında', 'text'),
        'dnz_fit_hall_features'  => array('Salon: özellikler başlığı', 'Özellikler', 'text'),
        'dnz_fit_hall_btn'       => array('Salon: talep düğmesi', 'Bu salon için talep oluştur ↗', 'text'),
    ));

    $S['dnz_sec_footer'] = array('Alt Bilgi (Footer)', array(
        'dnz_fit_footer_title'   => array('Alt bilgi başlığı', 'DNZ FİT', 'text'),
        'dnz_fit_footer_text'    => array('Alt bilgi sloganı', 'Hareket et. Güçlen. Geliş.', 'text'),
        'dnz_fit_footer_phone'   => array('Telefon', '', 'text'),
        'dnz_fit_footer_email'   => array('E-posta', '', 'text'),
        'dnz_fit_footer_address' => array('Adres', '', 'text'),
        'dnz_fit_footer_copy'    => array('Telif yazısı ({yıl} otomatik yıl olur)', '© {yıl} DNZ FİT. Tüm hakları saklıdır.', 'text'),
    ));

    $S['dnz_sec_colors'] = array('Renkler', array(
        'dnz_fit_color_lime' => array('Vurgu rengi (düğmeler, çizgiler)', '#c8ff3d', 'color'),
        'dnz_fit_color_dark' => array('Koyu renk (üst menü, kapak, alt bilgi)', '#101410', 'color'),
    ));

    $d = array('sections' => array(), 'fields' => array());
    foreach ($S as $sid => $sec) {
        $d['sections'][$sid] = $sec[0];
        foreach ($sec[1] as $fid => $f) {
            $f[3] = isset($f[3]) ? $f[3] : array();
            $f[4] = $sid;
            $d['fields'][$fid] = $f;
        }
    }
    return $d;
}

function dnz_fit_head_defs($p, $eyebrow, $title, $lead) {
    return array(
        'dnz_fit_' . $p . '_eyebrow' => array('Küçük üst yazı', $eyebrow, 'text'),
        'dnz_fit_' . $p . '_title'   => array('Başlık', $title, 'text'),
        'dnz_fit_' . $p . '_lead'    => array('Açıklama', $lead, 'textarea'),
    );
}

function dnz_fit_def($id) {
    $d = dnz_fit_defs();
    return isset($d['fields'][$id]) ? $d['fields'][$id] : null;
}

/* ---------- Değer okuma ---------- */
function dnz_fit_val($id) {
    $f = dnz_fit_def($id);
    return get_theme_mod($id, $f ? $f[1] : '');
}

function dnz_fit_inner($id) {
    $f = dnz_fit_def($id);
    $v = str_replace('{yıl}', wp_date('Y'), (string) dnz_fit_val($id));
    return ($f && $f[2] === 'textarea') ? nl2br(esc_html($v)) : esc_html($v);
}

/* Düzenlenebilir yazı: önizlemede yanında kalem çıkar */
function dnz_fit_t($id, $tag = 'span', $class = '') {
    $inner = dnz_fit_inner($id);
    if ($inner === '' && !is_customize_preview()) return '';
    return '<' . $tag . ($class ? ' class="' . esc_attr($class) . '"' : '') . ' data-dnz="' . esc_attr($id) . '">' . $inner . '</' . $tag . '>';
}

/* Bölüm başlığı (küçük yazı + başlık + açıklama) */
function dnz_fit_head($p) {
    return '<div class="section-head"><div>' . dnz_fit_t('dnz_fit_' . $p . '_eyebrow', 'div', 'eyebrow') . dnz_fit_t('dnz_fit_' . $p . '_title', 'h2') . '</div>' . dnz_fit_t('dnz_fit_' . $p . '_lead', 'p', 'lead') . '</div>';
}

/* Renkli/koyu çağrı kutusu */
function dnz_fit_band($title_id, $text_id, $btn_id, $url, $margin = true) {
    return '<div class="band"' . ($margin ? ' style="margin-top:34px"' : '') . '><div>' . dnz_fit_t($title_id, 'h2') . dnz_fit_t($text_id, 'p') . '</div>'
        . '<a class="btn dark" href="' . esc_url($url) . '">' . dnz_fit_t($btn_id) . '</a></div>';
}

/* ---------- Görseller ---------- */
function dnz_fit_img_url($id, $size = 'large') {
    $v = dnz_fit_val($id);
    if (!$v) return '';
    if (is_numeric($v)) return (string) wp_get_attachment_image_url((int) $v, $size);
    return esc_url_raw($v);
}

function dnz_fit_img_box($id) {
    $f = dnz_fit_def($id);
    $class = ($f && !empty($f[3]['class'])) ? $f[3]['class'] : 'dnz-img';
    $url = dnz_fit_img_url($id, 'large');
    return '<div class="' . esc_attr($class) . '" data-dnz-img="' . esc_attr($id) . '">' . ($url ? '<img src="' . esc_url($url) . '" alt="" loading="lazy">' : '') . '</div>';
}

function dnz_fit_render_image($id) {
    $f = dnz_fit_def($id);
    if ($f && !empty($f[3]['render']) && is_callable($f[3]['render'])) return call_user_func($f[3]['render']);
    return dnz_fit_img_box($id);
}

function dnz_fit_logo_html() {
    $url = dnz_fit_img_url('dnz_fit_logo', 'medium');
    if ($url) return '<span class="brand-icon has-img" data-dnz-img="dnz_fit_logo"><img src="' . esc_url($url) . '" alt=""></span>';
    return '<span class="brand-icon" data-dnz-img="dnz_fit_logo">' . dnz_fit_t('dnz_fit_logo_letter') . '</span>';
}

function dnz_fit_hero_graphic() {
    $url = dnz_fit_img_url('dnz_fit_hero_image', 'large');
    $h = '<div class="hero-graphic' . ($url ? ' has-img' : '') . '" data-dnz-img="dnz_fit_hero_image"' . ($url ? ' style="background-image:url(' . esc_attr(esc_url($url)) . ')"' : '') . '>';
    if (!$url) $h .= dnz_fit_t('dnz_fit_hero_big', 'strong');
    return $h . dnz_fit_t('dnz_fit_hero_small', 'small') . '</div>';
}

/* Siteyi gezen yönetici için düzenleme araçları (Özelleştirici önizlemesinde görünmez) */
function dnz_fit_frontend_edit() {
    return is_user_logged_in() && current_user_can('edit_posts') && !is_customize_preview();
}

function dnz_fit_edit_link($post_id) {
    if (!dnz_fit_frontend_edit() || !$post_id || !current_user_can('edit_post', $post_id)) return '';
    $url = get_edit_post_link($post_id);
    if (!$url) return '';
    $attr = in_array(get_post_type($post_id), dnz_fit_gallery_types(), true) ? ' data-dnz-edit="' . (int) $post_id . '"' : '';
    return '<a class="dnz-edit" href="' . esc_url($url) . '"' . $attr . ' title="Düzenle" aria-label="Düzenle">✎</a>';
}

function dnz_fit_photo_btn($post_id) {
    if (!dnz_fit_frontend_edit() || !current_user_can('edit_post', $post_id)) return '';
    return '<button type="button" class="dnz-photo-btn" data-dnz-photo="' . (int) $post_id . '">📷 ' . (has_post_thumbnail($post_id) ? 'Fotoğrafı değiştir' : 'Fotoğraf ekle') . '</button>';
}

function dnz_fit_add_card($type) {
    if (!dnz_fit_frontend_edit() || !current_user_can('edit_posts')) return '';
    $labels = array('dnz_coach' => 'Yeni antrenör ekle', 'dnz_program' => 'Yeni ders ekle', 'dnz_hall' => 'Yeni salon ekle', 'dnz_plan' => 'Yeni üyelik paketi ekle');
    if (!isset($labels[$type])) return '';
    return '<article class="card dnz-add-card"><button type="button" data-dnz-new="' . esc_attr($type) . '"><span>＋</span>' . esc_html($labels[$type]) . '</button></article>';
}

/* ---------- Özelleştirici kaydı ---------- */
function dnz_fit_sanitize_image($v) {
    return is_numeric($v) ? absint($v) : esc_url_raw((string) $v);
}

function dnz_fit_customizer($wp_customize) {
    $defs = dnz_fit_defs();
    $prio = 29;
    foreach ($defs['sections'] as $sid => $title) {
        $wp_customize->add_section($sid, array('title' => 'DNZ FİT: ' . $title, 'priority' => ++$prio));
    }
    $sr = isset($wp_customize->selective_refresh) ? $wp_customize->selective_refresh : null;

    foreach ($defs['fields'] as $id => $f) {
        list($label, $default, $type, $opts, $sec) = $f;
        $san = array('text' => 'sanitize_text_field', 'textarea' => 'sanitize_textarea_field', 'image' => 'dnz_fit_sanitize_image', 'color' => 'sanitize_hex_color');
        $wp_customize->add_setting($id, array(
            'default' => $default, 'sanitize_callback' => $san[$type],
            'transport' => ($type === 'color' || !$sr) ? 'refresh' : 'postMessage',
        ));
        if ($type === 'image') {
            $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, $id, array('label' => $label, 'section' => $sec, 'mime_type' => 'image')));
        } elseif ($type === 'color') {
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, $id, array('label' => $label, 'section' => $sec)));
        } else {
            $wp_customize->add_control($id, array('label' => $label, 'section' => $sec, 'type' => $type));
        }
        if (!$sr || $type === 'color') continue;

        if ($type === 'image') {
            $sr->add_partial($id, array(
                'selector' => '[data-dnz-img="' . $id . '"]', 'settings' => array($id), 'container_inclusive' => true,
                'render_callback' => function () use ($id) { echo dnz_fit_render_image($id); },
            ));
        } else {
            $sr->add_partial($id, array(
                'selector' => '[data-dnz="' . $id . '"]', 'settings' => array($id), 'container_inclusive' => false,
                'render_callback' => function () use ($id) { echo dnz_fit_inner($id); },
            ));
        }
    }
}
add_action('customize_register', 'dnz_fit_customizer');

/* Renk ayarları */
function dnz_fit_color_css() {
    $lime = sanitize_hex_color(dnz_fit_val('dnz_fit_color_lime'));
    $dark = sanitize_hex_color(dnz_fit_val('dnz_fit_color_dark'));
    $css = '';
    if ($lime && strtolower($lime) !== '#c8ff3d') $css .= '--lime:' . $lime . ';';
    if ($dark && strtolower($dark) !== '#101410') $css .= '--dark:' . $dark . ';';
    if ($css) echo '<style id="dnz-colors">:root{' . $css . '}</style>' . "\n";
}
add_action('wp_head', 'dnz_fit_color_css', 20);
