<?php
if (!defined('ABSPATH')) exit;

function dnz_fit_cpt() {
    register_post_type('dnz_coach', array(
        'labels' => array('name'=>'Antrenörler','singular_name'=>'Antrenör','menu_name'=>'Antrenörler','all_items'=>'Tüm Antrenörler','add_new'=>'Yeni Antrenör','add_new_item'=>'Yeni Antrenör Ekle','edit_item'=>'Antrenörü Düzenle','view_item'=>'Antrenör Sayfasını Gör','search_items'=>'Antrenör Ara'),
        'public' => true, 'menu_icon' => 'dashicons-universal-access', 'menu_position' => 21,
        'supports' => array('title','editor','thumbnail','excerpt'), 'has_archive' => false,
        'rewrite' => array('slug' => 'antrenorler'),
    ));
    register_post_type('dnz_program', array(
        'labels' => array('name'=>'Dersler','singular_name'=>'Ders','menu_name'=>'Dersler','all_items'=>'Tüm Dersler','add_new'=>'Yeni Ders','add_new_item'=>'Yeni Ders Ekle','edit_item'=>'Dersi Düzenle','view_item'=>'Ders Sayfasını Gör','search_items'=>'Ders Ara'),
        'public' => true, 'menu_icon' => 'dashicons-heart', 'menu_position' => 22,
        'supports' => array('title','editor','thumbnail','excerpt'), 'has_archive' => false,
        'rewrite' => array('slug' => 'dersler'),
    ));
    register_post_type('dnz_hall', array(
        'labels' => array('name'=>'Spor Salonları','singular_name'=>'Spor Salonu','menu_name'=>'Spor Salonları','all_items'=>'Tüm Salonlar','add_new'=>'Yeni Salon','add_new_item'=>'Yeni Salon Ekle','edit_item'=>'Salonu Düzenle','view_item'=>'Salon Sayfasını Gör','search_items'=>'Salon Ara'),
        'public' => true, 'menu_icon' => 'dashicons-building', 'menu_position' => 23,
        'supports' => array('title','editor','thumbnail','excerpt'), 'has_archive' => false,
        'rewrite' => array('slug' => 'spor-salonlari'),
    ));
    /* Üyelik paketleri: kendi sayfası yok, Üyelik sayfasında listelenir */
    register_post_type('dnz_plan', array(
        'labels' => array('name'=>'Üyelik Paketleri','singular_name'=>'Üyelik Paketi','menu_name'=>'Üyelik Paketleri','all_items'=>'Tüm Paketler','add_new'=>'Yeni Paket','add_new_item'=>'Yeni Üyelik Paketi Ekle','edit_item'=>'Paketi Düzenle'),
        'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-tickets-alt', 'menu_position' => 24,
        'supports' => array('title','excerpt','page-attributes','thumbnail'), 'has_archive' => false, 'rewrite' => false,
    ));
    /* Gelen rezervasyon ve üyelik talepleri */
    register_post_type('dnz_request', array(
        'labels' => array('name'=>'Talepler','singular_name'=>'Talep','menu_name'=>'Talepler','all_items'=>'Tüm Talepler','edit_item'=>'Talebi Görüntüle','search_items'=>'Talep Ara','not_found'=>'Henüz talep yok.'),
        'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-email-alt', 'menu_position' => 25,
        'supports' => array('title'), 'has_archive' => false, 'rewrite' => false,
        'capabilities' => array('create_posts' => 'do_not_allow'), 'map_meta_cap' => true,
    ));
}
add_action('init', 'dnz_fit_cpt');
