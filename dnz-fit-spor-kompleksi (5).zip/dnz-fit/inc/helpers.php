<?php
if (!defined('ABSPATH')) exit;

/* Meta değeri (tüm özel alanlar _dnz_ önekiyle saklanır) */
function dnz_fit_meta($id, $key) {
    return get_post_meta($id, '_dnz_' . $key, true);
}

/* Çok satırlı metni satır dizisine çevirir */
function dnz_fit_lines($text) {
    $out = array();
    foreach (preg_split('/\r\n|\r|\n/', (string) $text) as $line) {
        $line = trim($line);
        if ($line !== '') $out[] = $line;
    }
    return $out;
}

/* Fiyat gösterimi: boşsa yönlendirme, sayıysa ₺, metinse olduğu gibi */
function dnz_fit_money($v) {
    $v = trim((string) $v);
    if ($v === '') return 'Fiyat için iletişime geçin';
    if (preg_match('/^\d+([.,]\d+)?$/', $v)) {
        $n = (float) str_replace(',', '.', $v);
        return number_format_i18n($n, floor($n) == $n ? 0 : 2) . ' ₺';
    }
    return $v;
}

function dnz_fit_posts($type, $args = array()) {
    return get_posts(array_merge(array(
        'post_type' => $type, 'numberposts' => -1, 'post_status' => 'publish',
        'orderby' => 'title', 'order' => 'ASC',
    ), $args));
}

function dnz_fit_upper($s) {
    return function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
}

function dnz_fit_initials($title) {
    $out = '';
    foreach (preg_split('/\s+/', trim((string) $title)) as $w) {
        if ($w === '') continue;
        $out .= function_exists('mb_substr') ? mb_substr($w, 0, 1, 'UTF-8') : substr($w, 0, 1);
        if (strlen($out) >= 4) break;
    }
    return dnz_fit_upper($out ?: 'DNZ');
}

function dnz_fit_short_text($post_id, $words = 22) {
    $p = get_post($post_id);
    if (!$p) return '';
    $text = $p->post_excerpt !== '' ? $p->post_excerpt : strip_shortcodes(wp_strip_all_tags($p->post_content));
    return wp_trim_words($text, $words);
}

/* Antrenör / ders / salon / paket / yazı kartı (arşiv ve ana sayfa için ortak) */
function dnz_fit_card($post_id) {
    $type  = get_post_type($post_id);
    $title = get_the_title($post_id);
    $pill  = '';
    $meta  = array();
    $art   = 'DNZ';
    $cta   = 'Detayları gör';

    if ($type === 'dnz_coach') {
        $pill = dnz_fit_meta($post_id, 'role') ?: 'Antrenör';
        $art  = dnz_fit_initials($title);
        $cta  = 'Profil ve randevu';
        if ($s = dnz_fit_meta($post_id, 'specialty')) $meta[] = $s;
        $e = dnz_fit_meta($post_id, 'experience');
        if ($e !== '' && $e !== false) $meta[] = $e . ' yıl deneyim';
    } elseif ($type === 'dnz_program') {
        $pill = dnz_fit_meta($post_id, 'type') ?: 'Ders';
        $art  = 'DERS';
        $cta  = 'Ders sayfası ve kayıt';
        if (dnz_fit_price_rows($post_id) && ($low = dnz_fit_lowest_price($post_id)) !== '') $meta[] = 'Başlangıç: ' . dnz_fit_money($low);
        elseif (dnz_fit_meta($post_id, 'price') !== '') $meta[] = dnz_fit_money(dnz_fit_meta($post_id, 'price'));
        if ($x = dnz_fit_meta($post_id, 'sessions')) $meta[] = $x;
        if ($x = dnz_fit_meta($post_id, 'duration')) $meta[] = $x . ' dk';
    } elseif ($type === 'dnz_hall') {
        $pill = dnz_fit_meta($post_id, 'sport') ?: 'Salon';
        $art  = dnz_fit_upper($pill);
        $cta  = 'Salon sayfası ve rezervasyon';
        if ($x = dnz_fit_meta($post_id, 'capacity')) $meta[] = $x . ' kişi';
        if (dnz_fit_meta($post_id, 'price') !== '') $meta[] = dnz_fit_money(dnz_fit_meta($post_id, 'price')) . ' / saat';
    } else {
        $pill = get_the_date('', $post_id);
        $cta  = 'Devamını oku';
    }

    $h  = '<article class="card">' . dnz_fit_edit_link($post_id) . (in_array($type, array('dnz_coach', 'dnz_program', 'dnz_hall'), true) ? dnz_fit_photo_btn($post_id) : '');
    $h .= '<a href="' . esc_url(get_permalink($post_id)) . '" tabindex="-1" aria-hidden="true">';
    $h .= has_post_thumbnail($post_id) ? get_the_post_thumbnail($post_id, 'medium_large') : '<div class="card-art">' . esc_html($art) . '</div>';
    $h .= '</a><div class="card-body">';
    if ($pill) $h .= '<span class="pill">' . esc_html($pill) . '</span>';
    $h .= '<h3><a href="' . esc_url(get_permalink($post_id)) . '">' . esc_html($title) . '</a></h3>';
    if ($meta) $h .= '<p class="card-meta">' . esc_html(implode(' · ', $meta)) . '</p>';
    $h .= '<p>' . esc_html(dnz_fit_short_text($post_id)) . '</p>';
    $h .= '<a href="' . esc_url(get_permalink($post_id)) . '">' . esc_html($cta) . ' ↗</a>';
    $h .= '</div></article>';
    return $h;
}

/* Fotoğraf yoksa baş harfli kutu */
function dnz_fit_photo($post_id, $label) {
    if (has_post_thumbnail($post_id)) return get_the_post_thumbnail($post_id, 'large');
    return '<div class="photo-ph">' . esc_html($label) . '</div>';
}

/* Bölüm sayfalarının adresi (Antrenörler / Dersler / Salonlar sayfaları) */
function dnz_fit_section_slugs() {
    return array('dnz_coach' => 'antrenorler', 'dnz_program' => 'dersler', 'dnz_hall' => 'spor-salonlari');
}

function dnz_fit_section_url($type) {
    $slugs = dnz_fit_section_slugs();
    $slug  = isset($slugs[$type]) ? $slugs[$type] : '';
    if (!$slug) return home_url('/');
    $page = get_page_by_path($slug);
    return ($page && $page->post_status === 'publish') ? get_permalink($page->ID) : home_url('/' . $slug . '/');
}

/* Bölüm sayfalarındaki liste. $group_key doluysa o alana göre başlıklara ayırır. */
function dnz_fit_listing($type, $group_key = '', $suffix = '') {
    $posts = dnz_fit_posts($type, array('orderby' => 'menu_order title'));
    if (!$posts) {
        echo '<p>Henüz içerik eklenmedi.</p>';
        if ($add = dnz_fit_add_card($type)) echo '<div class="grid">' . $add . '</div>';
        return;
    }
    $groups = array();
    foreach ($posts as $p) {
        $g = $group_key ? (dnz_fit_meta($p->ID, $group_key) ?: 'Diğer') : '';
        $groups[$g][] = $p;
    }
    $n = 0; $total = count($groups);
    foreach ($groups as $label => $items) {
        $n++;
        if ($label !== '') echo '<h2 class="group-title">' . esc_html($label . $suffix) . '</h2>';
        echo '<div class="grid">';
        foreach ($items as $p) echo dnz_fit_card($p->ID);
        if ($n === $total) echo dnz_fit_add_card($type);
        echo '</div>';
    }
}
