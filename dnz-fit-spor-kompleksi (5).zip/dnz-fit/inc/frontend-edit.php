<?php
if (!defined('ABSPATH')) exit;

/* =========================================================
   SİTE İÇİ DÜZENLEME
   Giriş yapmış yönetici siteyi gezerken kartlardaki ✎ ve 📷
   düğmeleriyle antrenör, ders, salon ve paketleri (fotoğraf,
   galeri, fiyat dahil) panele girmeden düzenler, yenisini ekler.
   ========================================================= */

function dnz_fit_edit_assets() {
    if (!dnz_fit_frontend_edit()) return;
    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_style('dnz-fit-edit', get_template_directory_uri() . '/assets/edit.css', array(), DNZ_FIT_VERSION);
    wp_enqueue_script('dnz-fit-edit', get_template_directory_uri() . '/assets/edit.js', array('jquery', 'jquery-ui-sortable'), DNZ_FIT_VERSION, true);
    wp_localize_script('dnz-fit-edit', 'dnzEdit', array(
        'ajax'    => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('dnz_fit_edit'),
        'current' => is_singular() ? (int) get_queried_object_id() : 0,
        'home'    => home_url('/'),
    ));
}
add_action('wp_enqueue_scripts', 'dnz_fit_edit_assets');

function dnz_fit_edit_body_class($c) {
    if (dnz_fit_frontend_edit()) $c[] = 'dnz-editing';
    return $c;
}
add_filter('body_class', 'dnz_fit_edit_body_class');

/* ---------- Ortak kontroller ---------- */
function dnz_fit_ajax_guard($need_post = true) {
    check_ajax_referer('dnz_fit_edit', 'nonce');
    $id   = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $type = isset($_POST['type']) ? sanitize_key(wp_unslash($_POST['type'])) : '';
    if ($id) {
        $post = get_post($id);
        if (!$post || !in_array($post->post_type, dnz_fit_gallery_types(), true) || !current_user_can('edit_post', $id)) wp_send_json_error('Bu içeriği düzenleme yetkin yok.');
        $type = $post->post_type;
    } else {
        if ($need_post) wp_send_json_error('İçerik bulunamadı.');
        if (!in_array($type, dnz_fit_gallery_types(), true) || !current_user_can('edit_posts')) wp_send_json_error('Yetkin yok.');
    }
    return array($id, $type);
}

function dnz_fit_att($att) {
    $att = absint($att);
    return ($att && wp_attachment_is_image($att)) ? $att : 0;
}

function dnz_fit_att_json($att) {
    $thumb = wp_get_attachment_image_url($att, 'thumbnail');
    return array('id' => (int) $att, 'url' => $thumb ? $thumb : wp_get_attachment_url($att));
}

/* ---------- Formu doldurmak için veriyi ver ---------- */
function dnz_fit_ajax_load() {
    list($id, $type) = dnz_fit_ajax_guard(false);
    $post = $id ? get_post($id) : null;
    $defs = dnz_fit_fields();
    $fields = array();
    foreach ($defs[$type] as $key => $f) {
        list($label, $t, $extra) = $f;
        $val = $id ? dnz_fit_meta($id, $key) : '';
        $o = array('key' => $key, 'label' => $label, 'type' => $t, 'value' => $val, 'hint' => is_string($extra) ? $extra : '');
        if ($t === 'select') { $o['options'] = $extra; if ($val === '' || $val === false) $o['value'] = $extra[0]; }
        if ($t === 'coaches') {
            $o['options'] = array();
            foreach (dnz_fit_posts('dnz_coach', array('post_status' => array('publish', 'draft'))) as $c) $o['options'][] = array('id' => (string) $c->ID, 'title' => get_the_title($c));
            $o['value'] = is_array($val) ? array_map('strval', $val) : array();
        }
        if ($t === 'checkbox') $o['value'] = ($val === '1');
        $fields[] = $o;
    }
    $gallery = array();
    if ($id) foreach (dnz_fit_gallery_ids($id) as $g) $gallery[] = dnz_fit_att_json($g);
    $thumb_id = $id ? (int) get_post_thumbnail_id($id) : 0;
    $pto = get_post_type_object($type);
    wp_send_json_success(array(
        'id' => $id, 'type' => $type, 'typeLabel' => $pto->labels->singular_name,
        'title' => $post ? $post->post_title : '', 'excerpt' => $post ? $post->post_excerpt : '',
        'content' => $post ? $post->post_content : '', 'hasContent' => $type !== 'dnz_plan',
        'order' => $post ? (int) $post->menu_order : 0,
        'published' => $post ? ($post->post_status === 'publish') : true,
        'thumb' => $thumb_id ? dnz_fit_att_json($thumb_id) : null,
        'gallery' => $gallery,
        'hasPrices' => in_array($type, dnz_fit_price_types(), true),
        'prices' => $id ? dnz_fit_price_rows($id) : array(),
        'fields' => $fields,
        'pricesHint' => $type === 'dnz_plan' ? 'Aynı pakete farklı süre/fiyat ekle. Örn: 3 Aylık → 4000' : 'Örn: Tek seans → 500, 8 seans → 3200',
    ));
}
add_action('wp_ajax_dnz_fit_load', 'dnz_fit_ajax_load');

/* ---------- Kaydet (yeni veya mevcut) ---------- */
function dnz_fit_ajax_save() {
    list($id, $type) = dnz_fit_ajax_guard(false);
    $title = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
    if ($title === '') wp_send_json_error('Başlık boş olamaz.');
    $args = array(
        'post_title'   => $title,
        'post_excerpt' => isset($_POST['excerpt']) ? sanitize_textarea_field(wp_unslash($_POST['excerpt'])) : '',
        'menu_order'   => isset($_POST['order']) ? absint($_POST['order']) : 0,
        'post_status'  => !empty($_POST['published']) ? 'publish' : 'draft',
    );
    if ($type !== 'dnz_plan' && isset($_POST['content'])) $args['post_content'] = wp_kses_post(wp_unslash($_POST['content']));
    if ($id) { $args['ID'] = $id; $pid = wp_update_post(wp_slash($args), true); }
    else     { $args['post_type'] = $type; $pid = wp_insert_post(wp_slash($args), true); }
    if (is_wp_error($pid) || !$pid) wp_send_json_error('Kaydedilemedi. Lütfen tekrar dene.');

    $in = (isset($_POST['f']) && is_array($_POST['f'])) ? wp_unslash($_POST['f']) : array();
    dnz_fit_apply_fields($pid, $type, $in);
    $gal = isset($_POST['gallery']) && is_scalar($_POST['gallery']) ? sanitize_text_field(wp_unslash($_POST['gallery'])) : '';
    $prices = (isset($_POST['prices']) && is_array($_POST['prices'])) ? wp_unslash($_POST['prices']) : array();
    dnz_fit_apply_media($pid, $type, $gal, $prices);

    $att = isset($_POST['thumb_id']) ? dnz_fit_att($_POST['thumb_id']) : 0;
    if ($att) set_post_thumbnail($pid, $att); else delete_post_thumbnail($pid);
    delete_post_meta($pid, '_dnz_demo'); /* düzenlenen içerik artık "örnek" sayılmaz */
    wp_send_json_success(array('id' => (int) $pid));
}
add_action('wp_ajax_dnz_fit_save', 'dnz_fit_ajax_save');

/* ---------- Sil (çöpe taşı) ---------- */
function dnz_fit_ajax_delete() {
    list($id, $type) = dnz_fit_ajax_guard(true);
    if (!current_user_can('delete_post', $id)) wp_send_json_error('Silme yetkin yok.');
    wp_trash_post($id);
    wp_send_json_success(array('section' => dnz_fit_section_url($type)));
}
add_action('wp_ajax_dnz_fit_delete', 'dnz_fit_ajax_delete');

/* ---------- Kartın fotoğrafını hızlıca değiştir ---------- */
function dnz_fit_ajax_thumb() {
    list($id) = dnz_fit_ajax_guard(true);
    $att = isset($_POST['att']) ? dnz_fit_att($_POST['att']) : 0;
    if (!$att) wp_send_json_error('Geçerli bir fotoğraf seç.');
    set_post_thumbnail($id, $att);
    wp_send_json_success();
}
add_action('wp_ajax_dnz_fit_thumb', 'dnz_fit_ajax_thumb');

/* ---------- Galeriye hızlıca fotoğraf ekle ---------- */
function dnz_fit_ajax_gallery_add() {
    list($id) = dnz_fit_ajax_guard(true);
    $new = isset($_POST['atts']) && is_scalar($_POST['atts']) ? explode(',', sanitize_text_field(wp_unslash($_POST['atts']))) : array();
    $ids = dnz_fit_gallery_ids($id);
    foreach ($new as $a) { $a = dnz_fit_att($a); if ($a && !in_array($a, $ids, true)) $ids[] = $a; }
    update_post_meta($id, '_dnz_gallery', $ids);
    wp_send_json_success();
}
add_action('wp_ajax_dnz_fit_gallery_add', 'dnz_fit_ajax_gallery_add');
