<?php
if (!defined('ABSPATH')) exit;

/* Alan tanımları: anahtar => [etiket, tür, ipucu/seçenekler] */
function dnz_fit_fields() {
    return array(
        'dnz_coach' => array(
            'role'         => array('Unvan', 'text', 'Örn: Kişisel Antrenör'),
            'specialty'    => array('Uzmanlık alanları', 'text', 'Örn: Kuvvet, kilo yönetimi, basketbol'),
            'experience'   => array('Deneyim (yıl)', 'number', ''),
            'certs'        => array('Sertifikalar ve belgeler', 'textarea', 'Her satıra bir sertifika yaz.'),
            'availability' => array('Müsait gün ve saatler', 'textarea', 'Örn: Hafta içi 10:00–20:00'),
            'price'        => array('Seans ücreti', 'text', 'Örn: 800 (boş bırakılırsa gösterilmez)'),
        ),
        'dnz_program' => array(
            'type'     => array('Ders türü', 'select', array('Bireysel', 'Grup')),
            'price'    => array('Ücret', 'text', 'Örn: 3200 veya "8 seans 3200 ₺"'),
            'sessions' => array('Paket / seans sayısı', 'text', 'Örn: 8 seans'),
            'duration' => array('Seans süresi (dk)', 'number', ''),
            'days'     => array('Günler ve saatler', 'text', 'Örn: Pazartesi-Çarşamba 19:00'),
            'level'    => array('Seviye', 'text', 'Örn: Başlangıç / Orta'),
            'capacity' => array('Kontenjan (grup dersleri)', 'number', ''),
            'coaches'  => array('Dersi veren antrenörler', 'coaches', ''),
        ),
        'dnz_hall' => array(
            'sport'         => array('Spor türü', 'select', array('Basketbol', 'Voleybol', 'Diğer')),
            'capacity'      => array('Kapasite (kişi)', 'number', ''),
            'price'         => array('Saatlik kiralama ücreti', 'text', 'Örn: 1500'),
            'referee_price' => array('Hakem ücreti', 'text', 'Örn: 400'),
            'hours'         => array('Çalışma saatleri', 'text', 'Örn: Her gün 09:00–23:00'),
            'features'      => array('Özellikler', 'textarea', 'Her satıra bir özellik yaz (zemin, aydınlatma, tribün...).'),
        ),
        'dnz_plan' => array(
            'price'    => array('Fiyat', 'text', 'Örn: 1500'),
            'old_price' => array('Eski fiyat (üstü çizili)', 'text', 'İndirim göstermek için. Örn: 1800 (boş bırakılabilir)'),
            'period'   => array('Süre', 'text', 'Örn: Aylık, 3 Aylık, Yıllık'),
            'features' => array('Pakete dahil olanlar', 'textarea', 'Her satıra bir madde yaz.'),
            'featured' => array('Öne çıkan paket', 'checkbox', 'Bu paketi vurgulu göster'),
        ),
    );
}

function dnz_fit_request_statuses() {
    return array('yeni' => 'Yeni', 'onaylandi' => 'Onaylandı', 'iptal' => 'İptal / Reddedildi');
}

function dnz_fit_add_meta_boxes() {
    foreach (array_keys(dnz_fit_fields()) as $pt) {
        add_meta_box('dnz_details', 'DNZ FİT Detayları', 'dnz_fit_render_meta_box', $pt, 'normal', 'high');
    }
    add_meta_box('dnz_request_box', 'Talep Detayı', 'dnz_fit_render_request_box', 'dnz_request', 'normal', 'high');
}
add_action('add_meta_boxes', 'dnz_fit_add_meta_boxes');

function dnz_fit_render_meta_box($post) {
    $fields = dnz_fit_fields();
    wp_nonce_field('dnz_fit_meta', 'dnz_fit_meta_nonce');
    echo '<table class="form-table" role="presentation">';
    foreach ($fields[$post->post_type] as $key => $f) {
        list($label, $type, $extra) = $f;
        $val = get_post_meta($post->ID, '_dnz_' . $key, true);
        $name = 'dnz_f[' . $key . ']';
        echo '<tr><th scope="row"><label>' . esc_html($label) . '</label></th><td>';
        if ($type === 'textarea') {
            echo '<textarea class="large-text" rows="4" name="' . esc_attr($name) . '">' . esc_textarea($val) . '</textarea>';
        } elseif ($type === 'select') {
            echo '<select name="' . esc_attr($name) . '">';
            foreach ($extra as $opt) echo '<option' . selected($val, $opt, false) . '>' . esc_html($opt) . '</option>';
            echo '</select>';
        } elseif ($type === 'checkbox') {
            echo '<label><input type="checkbox" name="' . esc_attr($name) . '" value="1"' . checked($val, '1', false) . '> ' . esc_html($extra) . '</label>';
        } elseif ($type === 'coaches') {
            $sel = is_array($val) ? array_map('strval', $val) : array();
            $coaches = dnz_fit_posts('dnz_coach', array('post_status' => array('publish', 'draft')));
            if (!$coaches) echo '<em>Önce Antrenörler bölümünden antrenör ekle.</em>';
            foreach ($coaches as $c) {
                echo '<label style="display:block;margin:2px 0"><input type="checkbox" name="' . esc_attr($name) . '[]" value="' . esc_attr($c->ID) . '"' . checked(in_array((string) $c->ID, $sel, true), true, false) . '> ' . esc_html(get_the_title($c)) . '</label>';
            }
        } else {
            echo '<input class="regular-text" type="' . ($type === 'number' ? 'number' : 'text') . '"' . ($type === 'number' ? ' min="0"' : '') . ' name="' . esc_attr($name) . '" value="' . esc_attr($val) . '">';
        }
        if ($extra && is_string($extra) && $type !== 'checkbox') echo '<p class="description">' . esc_html($extra) . '</p>';
        echo '</td></tr>';
    }
    echo '</table>';
}

function dnz_fit_save_meta($post_id, $post) {
    if (!isset($_POST['dnz_fit_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnz_fit_meta_nonce'])), 'dnz_fit_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    $all = dnz_fit_fields();
    if (!isset($all[$post->post_type])) return;
    $in = (isset($_POST['dnz_f']) && is_array($_POST['dnz_f'])) ? wp_unslash($_POST['dnz_f']) : array();
    dnz_fit_apply_fields($post_id, $post->post_type, $in);
}

/* Alanları temizleyip kaydeder (panel ve site içi düzenleme penceresi ortak kullanır) */
function dnz_fit_apply_fields($post_id, $pt, $in) {
    $all = dnz_fit_fields();
    if (!isset($all[$pt])) return;
    foreach ($all[$pt] as $key => $f) {
        $type = $f[1];
        $val  = isset($in[$key]) ? $in[$key] : '';
        if ($type === 'textarea')      $val = sanitize_textarea_field($val);
        elseif ($type === 'number')    $val = ($val === '' || !is_scalar($val)) ? '' : (string) absint($val);
        elseif ($type === 'select')    $val = in_array($val, $f[2], true) ? $val : $f[2][0];
        elseif ($type === 'checkbox')  $val = $val ? '1' : '0';
        elseif ($type === 'coaches')   $val = array_values(array_filter(array_map('strval', array_map('absint', (array) $val))));
        else                           $val = sanitize_text_field(is_scalar($val) ? $val : '');
        update_post_meta($post_id, '_dnz_' . $key, $val);
    }
}
add_action('save_post', 'dnz_fit_save_meta', 10, 2);

/* ---- Talepler: detay kutusu, durum, liste sütunları ---- */
function dnz_fit_render_request_box($post) {
    $d = get_post_meta($post->ID, '_dnz_request', true);
    $status = get_post_meta($post->ID, '_dnz_status', true) ?: 'yeni';
    wp_nonce_field('dnz_fit_status', 'dnz_fit_status_nonce');
    echo '<table class="widefat striped"><tbody>';
    if (is_array($d)) foreach ($d as $label => $val) {
        if ($val === '' || $val === null) continue;
        echo '<tr><th style="width:200px">' . esc_html($label) . '</th><td>' . nl2br(esc_html($val)) . '</td></tr>';
    }
    echo '</tbody></table>';
    echo '<p><label><strong>Durum:</strong> <select name="dnz_status">';
    foreach (dnz_fit_request_statuses() as $k => $v) echo '<option value="' . esc_attr($k) . '"' . selected($status, $k, false) . '>' . esc_html($v) . '</option>';
    echo '</select></label></p>';
    echo '<p class="description">Salon müsaitliği otomatik kontrol edilmez. Talebi arayıp/yazıp onayladıktan sonra durumu “Onaylandı” yap.</p>';
}

function dnz_fit_save_status($post_id) {
    if (!isset($_POST['dnz_fit_status_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnz_fit_status_nonce'])), 'dnz_fit_status')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    $s = isset($_POST['dnz_status']) ? sanitize_key(wp_unslash($_POST['dnz_status'])) : 'yeni';
    if (!isset(dnz_fit_request_statuses()[$s])) $s = 'yeni';
    update_post_meta($post_id, '_dnz_status', $s);
}
add_action('save_post_dnz_request', 'dnz_fit_save_status');

function dnz_fit_request_columns($cols) {
    return array(
        'cb' => $cols['cb'], 'title' => 'Talep', 'dnz_type' => 'Tür', 'dnz_phone' => 'Telefon',
        'dnz_date' => 'İstenen tarih', 'dnz_status' => 'Durum', 'date' => 'Geliş zamanı',
    );
}
add_filter('manage_dnz_request_posts_columns', 'dnz_fit_request_columns');

function dnz_fit_request_column_content($col, $post_id) {
    $d = get_post_meta($post_id, '_dnz_request', true);
    $d = is_array($d) ? $d : array();
    if ($col === 'dnz_type')   echo esc_html(get_post_meta($post_id, '_dnz_req_type', true) === 'uyelik' ? 'Üyelik' : 'Rezervasyon');
    if ($col === 'dnz_phone')  echo esc_html(isset($d['Telefon']) ? $d['Telefon'] : '');
    if ($col === 'dnz_date')   echo esc_html(isset($d['Tarih']) ? $d['Tarih'] : (isset($d['Başlangıç tarihi']) ? $d['Başlangıç tarihi'] : ''));
    if ($col === 'dnz_status') { $s = get_post_meta($post_id, '_dnz_status', true) ?: 'yeni'; $l = dnz_fit_request_statuses(); echo '<strong>' . esc_html($l[$s] ?? 'Yeni') . '</strong>'; }
}
add_action('manage_dnz_request_posts_custom_column', 'dnz_fit_request_column_content', 10, 2);
