<?php
if (!defined('ABSPATH')) exit;

function dnz_fit_kinds() {
    return array(
        'coach'   => 'Antrenörle randevu (PT)',
        'program' => 'Ders / program kaydı',
        'hall'    => 'Salon kiralama',
    );
}

function dnz_fit_notice($param, $messages) {
    if (!isset($_GET[$param])) return '';
    $s = sanitize_key(wp_unslash($_GET[$param]));
    if (!isset($messages[$s])) return '';
    return '<div class="notice' . ($s === 'sent' ? '' : ' error') . '" role="status">' . esc_html($messages[$s]) . '</div>';
}

function dnz_fit_select($name, $posts, $selected, $empty, $attrs = '') {
    $h = '<select name="' . esc_attr($name) . '"' . $attrs . '><option value="">' . esc_html($empty) . '</option>';
    foreach ($posts as $p) {
        $h .= '<option value="' . esc_attr($p->ID) . '"' . selected((int) $selected, (int) $p->ID, false) . '>' . esc_html(get_the_title($p)) . '</option>';
    }
    return $h . '</select>';
}

function dnz_fit_back_url($default) {
    $raw = isset($_POST['back']) ? esc_url_raw(wp_unslash($_POST['back'])) : '';
    return wp_validate_redirect($raw, $default);
}

function dnz_fit_back($back, $param, $status, $anchor) {
    wp_safe_redirect(add_query_arg($param, $status, $back) . '#' . $anchor);
    exit;
}

function dnz_fit_current_url($default) {
    return is_singular() ? get_permalink(get_queried_object_id()) : $default;
}

function dnz_fit_save_request($type, $title, $details) {
    $id = wp_insert_post(wp_slash(array('post_type' => 'dnz_request', 'post_status' => 'publish', 'post_title' => $title)), true);
    if (is_wp_error($id) || !$id) return 0;
    update_post_meta($id, '_dnz_request', wp_slash($details));
    update_post_meta($id, '_dnz_req_type', $type);
    update_post_meta($id, '_dnz_status', 'yeni');
    return $id;
}

function dnz_fit_notify($subject, $details, $name, $email, $id) {
    $lines = array();
    foreach ($details as $label => $val) {
        if ($val !== '' && $val !== null) $lines[] = $label . ': ' . $val;
    }
    $lines[] = '';
    if ($id) $lines[] = 'Panelde görüntüle: ' . admin_url('post.php?post=' . $id . '&action=edit');
    $headers = array('Reply-To: ' . $name . ' <' . $email . '>');
    return wp_mail(apply_filters('dnz_fit_notify_email', get_option('admin_email')), $subject, implode("\n", $lines), $headers);
}

function dnz_fit_valid_date($date) {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date && $date >= wp_date('Y-m-d');
}

function dnz_fit_pretty_date($date) {
    $ts = strtotime($date . ' 12:00:00');
    return $ts ? wp_date('d.m.Y', $ts) : $date;
}

/* =========================================================
   REZERVASYON FORMU  [dnz_fit_reservation_form]
   Parametreler: kind (coach|program|hall), coach, program, hall
   ========================================================= */
function dnz_fit_reservation_form($atts = array()) {
    $a = shortcode_atts(array('kind' => '', 'coach' => 0, 'program' => 0, 'hall' => 0), $atts, 'dnz_fit_reservation_form');
    foreach (array('kind', 'coach', 'program', 'hall') as $k) {
        if (empty($a[$k]) && isset($_GET[$k])) $a[$k] = sanitize_text_field(wp_unslash($_GET[$k]));
    }
    $coach = absint($a['coach']); $program = absint($a['program']); $hall = absint($a['hall']);
    $sel_pkg = isset($_GET['pkg']) ? absint($_GET['pkg']) : -1;
    $programs_all = dnz_fit_posts('dnz_program');
    $kinds = dnz_fit_kinds();
    $kind  = sanitize_key($a['kind']);
    if (!isset($kinds[$kind])) $kind = $coach ? 'coach' : ($program ? 'program' : ($hall ? 'hall' : ''));
    $back  = dnz_fit_current_url(home_url('/rezervasyon/'));

    ob_start();
    echo '<div class="form-card" id="talep">';
    echo dnz_fit_notice('dnz_res', array(
        'sent'     => 'Talebin bize ulaştı. Rezervasyon henüz kesinleşmedi; ekibimiz seninle iletişime geçip müsaitliği teyit edecek.',
        'missing'  => 'Lütfen zorunlu alanları (*) eksiksiz doldur.',
        'date'     => 'Tarih bugünden önce olamaz. Lütfen geçerli bir tarih seç.',
        'consent'  => 'Talebi gönderebilmek için kişisel veri onayını işaretlemelisin.',
        'error'    => 'Talebin kaydedilemedi. Lütfen daha sonra tekrar dene veya bizi ara.',
    ));
    ?>
    <form class="dnz-form" id="dnz-res-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="dnz_fit_reservation">
      <input type="hidden" name="back" value="<?php echo esc_url($back); ?>">
      <?php wp_nonce_field('dnz_fit_reservation', 'dnz_fit_nonce'); ?>
      <div class="hp" aria-hidden="true"><label>Web sitesi<input name="website" tabindex="-1" autocomplete="off"></label></div>

      <div class="full"><label>Ne için rezervasyon yapıyorsun? *
        <select name="kind" required>
          <option value="">Seçiniz</option>
          <?php foreach ($kinds as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($kind, $k, false) . '>' . esc_html($l) . '</option>'; ?>
        </select></label></div>

      <div class="full" data-show="coach"><label>Antrenör
        <?php echo dnz_fit_select('coach', dnz_fit_posts('dnz_coach'), $coach, 'Fark etmez / uygun olan antrenör'); ?></label></div>

      <div class="full" data-show="program"><label>Ders / program *
        <?php echo dnz_fit_select('program', $programs_all, $program, 'Seçiniz', ' data-req="1"'); ?></label>
        <label id="dnz-pkg-wrap" hidden style="margin-top:14px">Fiyat / paket seçeneği
          <select name="pkg" data-sel="<?php echo $sel_pkg >= 0 ? (int) $sel_pkg : ''; ?>"><option value="">Henüz seçmedim</option>
          <?php foreach ($programs_all as $pp) foreach (dnz_fit_price_rows($pp->ID) as $i => $r) echo '<option value="' . (int) $i . '" data-program="' . (int) $pp->ID . '">' . esc_html(dnz_fit_price_row_text($r)) . '</option>'; ?>
          </select></label></div>

      <div class="full" data-show="hall"><label>Salon *
        <?php echo dnz_fit_select('hall', dnz_fit_posts('dnz_hall'), $hall, 'Seçiniz', ' data-req="1"'); ?></label></div>

      <div><label>Tercih edilen tarih *<input type="date" name="date" required min="<?php echo esc_attr(wp_date('Y-m-d')); ?>"></label></div>
      <div><label>Tercih edilen saat<input type="time" name="time" data-req-kind="hall"></label></div>

      <div data-show="hall"><label>Süre
        <select name="duration"><option>1 saat</option><option>1,5 saat</option><option>2 saat</option><option>3 saat</option></select></label></div>
      <div data-show="program hall"><label>Kişi sayısı<input type="number" name="people" min="1" max="200" placeholder="Örn: 10"></label></div>

      <div class="full" data-show="hall"><label class="check"><input type="checkbox" name="referee" value="1"> Hakem hizmeti de istiyorum</label></div>

      <div><label>Ad Soyad *<input name="name" required autocomplete="name"></label></div>
      <div><label>Telefon *<input name="phone" type="tel" required autocomplete="tel" placeholder="05xx xxx xx xx"></label></div>
      <div class="full"><label>E-posta *<input type="email" name="email" required autocomplete="email"></label></div>
      <div class="full"><label>Ek bilgiler<textarea name="notes" placeholder="Hedefin, takım/grup bilgisi, özel isteklerin..."></textarea></label></div>

      <div class="full"><label class="check"><input type="checkbox" name="consent" value="1" required> Kişisel verilerimin bu talebi yanıtlamak amacıyla işlenmesini kabul ediyorum. *</label></div>
      <div class="full"><button class="btn" type="submit">Rezervasyon talebi gönder ↗</button>
        <p class="post-meta">Bu form bir talep iletir. Salon müsaitliği ve rezervasyonun kesinliği ekibimiz tarafından telefonla/e-postayla onaylanır.</p></div>
    </form>
    <script>
    (function(){var f=document.getElementById('dnz-res-form');if(!f)return;var k=f.elements['kind'];
    function sync(){var v=k.value;
      f.querySelectorAll('[data-show]').forEach(function(g){
        var on=v&&g.getAttribute('data-show').split(' ').indexOf(v)>-1;g.hidden=!on;
        g.querySelectorAll('input,select,textarea').forEach(function(i){i.disabled=!on;if(i.hasAttribute('data-req'))i.required=on;});});
      f.querySelectorAll('[data-req-kind]').forEach(function(i){i.required=(v===i.getAttribute('data-req-kind'));});}
    k.addEventListener('change',sync);sync();})();
    (function(){var f=document.getElementById('dnz-res-form');if(!f)return;var p=f.elements['program'],o=f.elements['pkg'],w=document.getElementById('dnz-pkg-wrap');if(!p||!o||!w)return;
    var all=Array.prototype.slice.call(o.options,1).map(function(x){return{v:x.value,t:x.text,p:x.getAttribute('data-program')};});var want=o.getAttribute('data-sel');
    function sync(){var keep=o.value||want;want='';while(o.options.length>1)o.remove(1);var n=0;
      all.forEach(function(a){if(a.p===p.value){var x=new Option(a.t,a.v);if(a.v===keep)x.selected=true;o.add(x);n++;}});w.hidden=!n;}
    p.addEventListener('change',function(){o.value='';sync();});sync();})();
    </script>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dnz_fit_reservation_form', 'dnz_fit_reservation_form');

function dnz_fit_reservation_handler() {
    if (!isset($_POST['dnz_fit_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnz_fit_nonce'])), 'dnz_fit_reservation')) {
        wp_die('Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip formu tekrar gönderin.');
    }
    $back = dnz_fit_back_url(home_url('/rezervasyon/'));
    if (!empty($_POST['website'])) dnz_fit_back($back, 'dnz_res', 'sent', 'talep'); /* bot: sessizce geç */

    $g = function ($k) { return isset($_POST[$k]) && is_scalar($_POST[$k]) ? sanitize_text_field(wp_unslash($_POST[$k])) : ''; };
    $kinds = dnz_fit_kinds();
    $kind  = sanitize_key($g('kind'));
    $name  = $g('name'); $email = sanitize_email($g('email')); $phone = $g('phone');
    $date  = $g('date'); $time = $g('time');
    $notes = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash($_POST['notes'])) : '';

    if (!isset($kinds[$kind]) || !$name || !is_email($email) || !$phone || !$date) dnz_fit_back($back, 'dnz_res', 'missing', 'talep');
    if (empty($_POST['consent'])) dnz_fit_back($back, 'dnz_res', 'consent', 'talep');
    if (!dnz_fit_valid_date($date)) dnz_fit_back($back, 'dnz_res', 'date', 'talep');
    if ($time !== '' && !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time)) $time = '';

    $types  = array('coach' => 'dnz_coach', 'program' => 'dnz_program', 'hall' => 'dnz_hall');
    $labels = array('coach' => 'Antrenör', 'program' => 'Ders', 'hall' => 'Salon');
    $target = '';
    $tid = absint($g($kind));
    if ($tid && get_post_type($tid) === $types[$kind] && get_post_status($tid) === 'publish') $target = get_the_title($tid);
    if ($kind !== 'coach' && $target === '') dnz_fit_back($back, 'dnz_res', 'missing', 'talep');
    if ($kind === 'hall' && $time === '') dnz_fit_back($back, 'dnz_res', 'missing', 'talep');
    if ($kind === 'coach' && $target === '') $target = 'Fark etmez';

    $pkg_text = '';
    if ($kind === 'program' && $tid && $g('pkg') !== '') {
        $rows = dnz_fit_price_rows($tid);
        $pi = absint($g('pkg'));
        if (isset($rows[$pi])) $pkg_text = dnz_fit_price_row_text($rows[$pi]);
    }
    $people = absint($g('people'));
    $details = array(
        'Talep türü'       => $kinds[$kind],
        $labels[$kind]     => $target,
        'Fiyat seçeneği'   => $pkg_text,
        'Tarih'            => dnz_fit_pretty_date($date),
        'Saat'             => $time,
        'Süre'             => $kind === 'hall' ? $g('duration') : '',
        'Kişi sayısı'      => ($kind !== 'coach' && $people) ? (string) $people : '',
        'Hakem hizmeti'    => $kind === 'hall' ? (!empty($_POST['referee']) ? 'Evet' : 'Hayır') : '',
        'Ad Soyad'         => $name,
        'E-posta'          => $email,
        'Telefon'          => $phone,
        'Not'              => $notes,
    );
    $title = '[Rezervasyon] ' . $name . ' – ' . $kinds[$kind] . ' – ' . dnz_fit_pretty_date($date);
    $id = dnz_fit_save_request('rezervasyon', $title, $details);
    dnz_fit_notify('DNZ FİT - Yeni rezervasyon talebi', $details, $name, $email, $id);
    dnz_fit_back($back, 'dnz_res', $id ? 'sent' : 'error', 'talep');
}
add_action('admin_post_nopriv_dnz_fit_reservation', 'dnz_fit_reservation_handler');
add_action('admin_post_dnz_fit_reservation', 'dnz_fit_reservation_handler');

/* =========================================================
   ÜYELİK  [dnz_fit_membership]  (paketler + başvuru formu)
   ========================================================= */
function dnz_fit_membership($atts = array()) {
    $plans    = dnz_fit_posts('dnz_plan', array('orderby' => 'menu_order title', 'order' => 'ASC'));
    $selected = isset($_GET['plan']) ? absint($_GET['plan']) : 0;
    $sel_opt  = isset($_GET['opt']) ? absint($_GET['opt']) : -1;
    $page_url = dnz_fit_current_url(home_url('/uyelik/'));

    ob_start();
    if ($plans || dnz_fit_frontend_edit()) {
        echo '<div class="plans">';
        foreach ($plans as $p) echo dnz_fit_plan_card($p, $page_url);
        echo dnz_fit_add_card('dnz_plan');
        echo '</div>';
    }

    echo '<div class="form-card" id="uyelik-formu"><h2>Üyelik başvurusu</h2>';
    echo dnz_fit_notice('dnz_mem', array(
        'sent'    => 'Başvurun bize ulaştı. Ekibimiz seninle iletişime geçip üyelik işlemlerini tamamlayacak.',
        'missing' => 'Lütfen zorunlu alanları (*) eksiksiz doldur.',
        'date'    => 'Başlangıç tarihi bugünden önce olamaz.',
        'consent' => 'Başvuruyu gönderebilmek için kişisel veri onayını işaretlemelisin.',
        'error'   => 'Başvurun kaydedilemedi. Lütfen daha sonra tekrar dene veya bizi ara.',
    ));
    ?>
    <form class="dnz-form" id="dnz-mem-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="dnz_fit_membership">
      <input type="hidden" name="back" value="<?php echo esc_url($page_url); ?>">
      <?php wp_nonce_field('dnz_fit_membership', 'dnz_fit_nonce'); ?>
      <div class="hp" aria-hidden="true"><label>Web sitesi<input name="website" tabindex="-1" autocomplete="off"></label></div>
      <div class="full"><label>Üyelik paketi
        <?php echo dnz_fit_select('plan', $plans, $selected, 'Henüz karar vermedim, bilgi almak istiyorum'); ?></label></div>
      <div class="full"><label id="dnz-opt-wrap" hidden>Süre / fiyat seçeneği
        <select name="option" data-sel="<?php echo $sel_opt >= 0 ? (int) $sel_opt : ''; ?>"><option value="">Ana paket fiyatı</option>
        <?php foreach ($plans as $p) foreach (dnz_fit_price_rows($p->ID) as $i => $r) echo '<option value="' . (int) $i . '" data-plan="' . (int) $p->ID . '">' . esc_html(dnz_fit_price_row_text($r)) . '</option>'; ?>
        </select></label></div>
      <div><label>Ad Soyad *<input name="name" required autocomplete="name"></label></div>
      <div><label>Telefon *<input name="phone" type="tel" required autocomplete="tel" placeholder="05xx xxx xx xx"></label></div>
      <div><label>E-posta *<input type="email" name="email" required autocomplete="email"></label></div>
      <div><label>Başlamak istediğin tarih<input type="date" name="start" min="<?php echo esc_attr(wp_date('Y-m-d')); ?>"></label></div>
      <div class="full"><label>Hedefin
        <select name="goal"><option value="">Seçiniz</option><option>Kilo vermek</option><option>Kas kazanmak / güçlenmek</option><option>Genel sağlık ve kondisyon</option><option>Sporcu performansı</option><option>Diğer</option></select></label></div>
      <div class="full"><label>Ek bilgiler<textarea name="notes" placeholder="Sağlık durumun, tercih ettiğin saatler, sorular..."></textarea></label></div>
      <div class="full"><label class="check"><input type="checkbox" name="consent" value="1" required> Kişisel verilerimin bu başvuruyu yanıtlamak amacıyla işlenmesini kabul ediyorum. *</label></div>
      <div class="full"><button class="btn" type="submit">Üyelik başvurusu gönder ↗</button>
        <p class="post-meta">Başvuru ön talep niteliğindedir; üyelik, ekibimizle görüşme ve ödeme sonrasında başlar.</p></div>
    </form>
    <script>
    (function(){var f=document.getElementById('dnz-mem-form');if(!f)return;var p=f.elements['plan'],o=f.elements['option'],w=document.getElementById('dnz-opt-wrap');if(!p||!o||!w)return;
    var all=Array.prototype.slice.call(o.options,1).map(function(x){return{v:x.value,t:x.text,p:x.getAttribute('data-plan')};});var want=o.getAttribute('data-sel');
    function sync(){var keep=o.value||want;want='';while(o.options.length>1)o.remove(1);var n=0;
      all.forEach(function(a){if(a.p===p.value){var x=new Option(a.t,a.v);if(a.v===keep)x.selected=true;o.add(x);n++;}});w.hidden=!n;}
    p.addEventListener('change',function(){o.value='';sync();});sync();})();
    </script></div>
    <?php
    return ob_get_clean();
}
add_shortcode('dnz_fit_membership', 'dnz_fit_membership');

function dnz_fit_membership_handler() {
    if (!isset($_POST['dnz_fit_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnz_fit_nonce'])), 'dnz_fit_membership')) {
        wp_die('Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip formu tekrar gönderin.');
    }
    $back = dnz_fit_back_url(home_url('/uyelik/'));
    if (!empty($_POST['website'])) dnz_fit_back($back, 'dnz_mem', 'sent', 'uyelik-formu');

    $g = function ($k) { return isset($_POST[$k]) && is_scalar($_POST[$k]) ? sanitize_text_field(wp_unslash($_POST[$k])) : ''; };
    $name = $g('name'); $email = sanitize_email($g('email')); $phone = $g('phone'); $start = $g('start');
    $goals = array('Kilo vermek', 'Kas kazanmak / güçlenmek', 'Genel sağlık ve kondisyon', 'Sporcu performansı', 'Diğer');
    $goal  = in_array($g('goal'), $goals, true) ? $g('goal') : '';
    $notes = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash($_POST['notes'])) : '';

    if (!$name || !is_email($email) || !$phone) dnz_fit_back($back, 'dnz_mem', 'missing', 'uyelik-formu');
    if (empty($_POST['consent'])) dnz_fit_back($back, 'dnz_mem', 'consent', 'uyelik-formu');
    if ($start !== '' && !dnz_fit_valid_date($start)) dnz_fit_back($back, 'dnz_mem', 'date', 'uyelik-formu');

    $plan = 'Henüz seçilmedi';
    $option = '';
    $pid = absint($g('plan'));
    if ($pid && get_post_type($pid) === 'dnz_plan' && get_post_status($pid) === 'publish') {
        $plan = get_the_title($pid);
        if ($pr = dnz_fit_meta($pid, 'price')) $plan .= ' (' . dnz_fit_money($pr) . ')';
        $rows = dnz_fit_price_rows($pid);
        $oi = $g('option');
        if ($oi !== '' && isset($rows[absint($oi)])) $option = dnz_fit_price_row_text($rows[absint($oi)]);
    }
    $details = array(
        'Talep türü'         => 'Üyelik başvurusu',
        'Paket'              => $plan,
        'Süre / fiyat seçeneği' => $option,
        'Başlangıç tarihi'   => $start !== '' ? dnz_fit_pretty_date($start) : '',
        'Hedef'              => $goal,
        'Ad Soyad'           => $name,
        'E-posta'            => $email,
        'Telefon'            => $phone,
        'Not'                => $notes,
    );
    $id = dnz_fit_save_request('uyelik', '[Üyelik] ' . $name . ' – ' . $plan, $details);
    dnz_fit_notify('DNZ FİT - Yeni üyelik başvurusu', $details, $name, $email, $id);
    dnz_fit_back($back, 'dnz_mem', $id ? 'sent' : 'error', 'uyelik-formu');
}
add_action('admin_post_nopriv_dnz_fit_membership', 'dnz_fit_membership_handler');
add_action('admin_post_dnz_fit_membership', 'dnz_fit_membership_handler');
