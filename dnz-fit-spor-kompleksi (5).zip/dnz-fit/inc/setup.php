<?php
if (!defined('ABSPATH')) exit;

/* Tema etkinleştirilince (veya güncellenince) hazır sayfaları, örnek içerikleri ve menüyü kurar. */
function dnz_fit_maybe_setup() {
    if (current_user_can('manage_options') && get_option('dnz_fit_setup') !== DNZ_FIT_VERSION) dnz_fit_setup_site();
}
add_action('admin_init', 'dnz_fit_maybe_setup');
add_action('after_switch_theme', 'dnz_fit_setup_site');

function dnz_fit_setup_site() {
    dnz_fit_make_page('Rezervasyon', 'rezervasyon', '[dnz_fit_reservation_form]', 'template-reservation.php');
    dnz_fit_make_page('Üyelik', 'uyelik', '[dnz_fit_membership]', 'template-membership.php');
    dnz_fit_make_page('Antrenörler', 'antrenorler', 'Antrenörlerimizin uzmanlık alanlarını, özgeçmişlerini ve belgelerini incele; kendine uygun olandan randevu al.', 'template-coaches.php');
    dnz_fit_make_page('Dersler', 'dersler', 'Bireysel ve grup derslerini incele; ücret, gün ve saat bilgilerine bak, kayıt talebi oluştur.', 'template-programs.php');
    dnz_fit_make_page('Spor Salonları', 'spor-salonlari', 'Basketbol ve voleybol salonlarımızı incele; hakem hizmeti dahil kiralama talebi oluştur.', 'template-halls.php');
    dnz_fit_seed_content();
    dnz_fit_make_menu();
    flush_rewrite_rules(false);
    update_option('dnz_fit_setup', DNZ_FIT_VERSION);
}

function dnz_fit_make_page($title, $slug, $content, $template) {
    $existing = get_page_by_path($slug);
    if ($existing) {
        /* Eskiden elle açılmış sayfa varsa dokunma; sadece şablonu yoksa ata */
        if (strpos($existing->post_content, trim($content, '[]')) !== false && !get_post_meta($existing->ID, '_wp_page_template', true)) {
            update_post_meta($existing->ID, '_wp_page_template', $template);
        }
        return;
    }
    $id = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content));
    if ($id && !is_wp_error($id)) update_post_meta($id, '_wp_page_template', $template);
}

function dnz_fit_seed_item($type, $title, $content, $meta = array(), $demo = true, $order = 0, $excerpt = '') {
    $id = wp_insert_post(array('post_type' => $type, 'post_status' => 'publish', 'post_title' => $title, 'post_content' => $content, 'post_excerpt' => $excerpt, 'menu_order' => $order));
    if (!$id || is_wp_error($id)) return 0;
    foreach ($meta as $k => $v) update_post_meta($id, '_dnz_' . $k, $v);
    if ($demo) update_post_meta($id, '_dnz_demo', '1');
    return $id;
}

function dnz_fit_has_posts($type) {
    return (bool) get_posts(array('post_type' => $type, 'numberposts' => 1, 'post_status' => 'any', 'fields' => 'ids'));
}

function dnz_fit_seed_content() {
    if (get_option('dnz_fit_seeded')) return;
    $note = "Bu bir ÖRNEK sayfadır. Yönetim panelinden içeriği, fotoğrafı ve ayrıntıları kendi bilgilerinle değiştir; yayına almadan önce gerçek bilgileri gir.";

    $coach_ids = array();
    if (!dnz_fit_has_posts('dnz_coach')) {
        $coaches = array(
            array('Örnek Antrenör 1', 'Kişisel Antrenör (PT)', 'Bireysel PT, kuvvet ve kondisyon'),
            array('Örnek Antrenör 2', 'Grup Antrenörü', 'Grup dersleri, fonksiyonel antrenman'),
            array('Örnek Antrenör 3', 'Spor Antrenörü', 'Basketbol ve voleybol gelişimi'),
        );
        foreach ($coaches as $i => $c) {
            $coach_ids[] = dnz_fit_seed_item('dnz_coach', $c[0],
                $note . "\n\nBuraya antrenörün özgeçmişini, eğitim geçmişini ve çalışma yaklaşımını yaz.",
                array('role' => $c[1], 'specialty' => $c[2], 'certs' => "Sertifika adı 1\nSertifika adı 2", 'availability' => 'Müsait gün ve saatleri buraya yaz.'),
                true, $i, 'Örnek antrenör profili. Panelden Antrenörler bölümünden düzenle.');
        }
    }
    if (!dnz_fit_has_posts('dnz_program')) {
        $programs = array(
            array('Bireysel PT Antrenmanı', 'Bireysel', 60, 'Hedefine ve seviyene göre antrenörle birebir çalışma.', array(0)),
            array('Grup Antrenmanı', 'Grup', 60, 'Birlikte motive olmak ve düzenli çalışmak isteyenler için grup dersi.', array(1)),
            array('Kilo Verme ve Form Programı', 'Bireysel', 60, 'Ölçüm, hedef belirleme ve haftalık antrenman planı içeren program.', array(0, 1)),
        );
        foreach ($programs as $i => $p) {
            $coaches = array();
            foreach ($p[4] as $ci) if (isset($coach_ids[$ci])) $coaches[] = (string) $coach_ids[$ci];
            dnz_fit_seed_item('dnz_program', $p[0],
                $note . "\n\nDersin kapsamını, neler yapılacağını, kimler için uygun olduğunu ve katılım koşullarını buraya yaz.",
                array('type' => $p[1], 'duration' => (string) $p[2], 'coaches' => $coaches, 'days' => 'Gün ve saatleri buraya yaz.'),
                true, $i, $p[3]);
        }
    }
    if (!dnz_fit_has_posts('dnz_hall')) {
        $halls = array(array('Basketbol Salonu 1', 'Basketbol'), array('Basketbol Salonu 2', 'Basketbol'), array('Voleybol Salonu 1', 'Voleybol'));
        foreach ($halls as $i => $h) {
            dnz_fit_seed_item('dnz_hall', $h[0],
                "Saha ölçüleri, zemin, aydınlatma, kapasite ve kiralama koşullarını panelden Spor Salonları bölümünden ekle. Rezervasyon talebinde hakem hizmeti de istenebilir.",
                array('sport' => $h[1], 'features' => "Soyunma odası ve duş erişimi\nOtopark"),
                false, $i, $h[0] . ' için kiralama talebi oluşturabilirsin.');
        }
    }
    if (!dnz_fit_has_posts('dnz_plan')) {
        $plans = array(
            array('Aylık Üyelik', 'Aylık', '0'),
            array('3 Aylık Üyelik', '3 Aylık', '1'),
            array('Yıllık Üyelik', 'Yıllık', '0'),
        );
        foreach ($plans as $i => $p) {
            dnz_fit_seed_item('dnz_plan', $p[0], '',
                array('period' => $p[1], 'featured' => $p[2], 'features' => "Tesis kullanımı\nDuş ve soyunma odası\nOtopark\nÜyelik sahibi olarak PT ve salon talebi oluşturma"),
                true, $i, 'Örnek paket. Fiyatı ve içeriği panelden Üyelik Paketleri bölümünden düzenle.');
        }
    }
    update_option('dnz_fit_seeded', '1');
}

function dnz_fit_make_menu() {
    /* Eski sürümde menüye eklenen /pt-programlari/ bağlantısını yeni /dersler/ adresine taşı */
    $old = wp_get_nav_menu_object('DNZ FİT Ana Menü');
    if ($old) {
        foreach ((array) wp_get_nav_menu_items($old->term_id) as $it) {
            if (strpos($it->url, '/pt-programlari') !== false) {
                wp_update_nav_menu_item($old->term_id, $it->db_id, array(
                    'menu-item-title' => $it->title, 'menu-item-url' => str_replace('/pt-programlari', '/dersler', $it->url),
                    'menu-item-type' => 'custom', 'menu-item-status' => 'publish',
                ));
            }
        }
    }
    $locations = get_nav_menu_locations();
    if (!empty($locations['primary'])) return;
    $name = 'DNZ FİT Ana Menü';
    $menu = wp_get_nav_menu_object($name);
    $menu_id = $menu ? $menu->term_id : wp_create_nav_menu($name);
    if (is_wp_error($menu_id) || !$menu_id) return;
    if (!wp_get_nav_menu_items($menu_id)) {
        $items = array(
            'Ana Sayfa'   => home_url('/'),
            'Dersler'     => dnz_fit_section_url('dnz_program'),
            'Antrenörler' => dnz_fit_section_url('dnz_coach'),
            'Salonlar'    => dnz_fit_section_url('dnz_hall'),
            'Üyelik'      => home_url('/uyelik/'),
            'Rezervasyon' => home_url('/rezervasyon/'),
        );
        foreach ($items as $label => $url) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' => $label, 'menu-item-url' => $url,
                'menu-item-type' => 'custom', 'menu-item-status' => 'publish',
            ));
        }
    }
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}

/* Örnek içerik uyarısı + tek tıkla silme */
function dnz_fit_demo_ids() {
    return get_posts(array(
        'post_type' => array('dnz_coach', 'dnz_program', 'dnz_plan'), 'numberposts' => -1, 'post_status' => 'any',
        'fields' => 'ids', 'meta_key' => '_dnz_demo', 'meta_value' => '1',
    ));
}

function dnz_fit_demo_notice() {
    if (!current_user_can('manage_options') || !dnz_fit_demo_ids()) return;
    $url = wp_nonce_url(admin_url('admin-post.php?action=dnz_fit_delete_demo'), 'dnz_fit_delete_demo');
    echo '<div class="notice notice-warning"><p><strong>DNZ FİT:</strong> Sitede örnek antrenör, ders ve üyelik paketi var. Gerçek içeriklerini ekledikten sonra yayına almadan önce örnekleri sil veya düzenle. ';
    echo '<a class="button" href="' . esc_url($url) . '" onclick="return confirm(\'Tüm örnek içerikler silinsin mi?\');">Örnek içerikleri sil</a></p></div>';
}
add_action('admin_notices', 'dnz_fit_demo_notice');

function dnz_fit_delete_demo() {
    if (!current_user_can('manage_options') || !check_admin_referer('dnz_fit_delete_demo')) wp_die('Yetkin yok.');
    foreach (dnz_fit_demo_ids() as $id) wp_delete_post($id, true);
    wp_safe_redirect(admin_url('index.php'));
    exit;
}
add_action('admin_post_dnz_fit_delete_demo', 'dnz_fit_delete_demo');

/* Eski /pt-programlari/ adreslerini yeni /dersler/ adresine yönlendir */
function dnz_fit_old_urls() {
    if (!is_404() || empty($_SERVER['REQUEST_URI'])) return;
    $path = trim((string) wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH), '/');
    if (preg_match('#(?:^|/)pt-programlari(?:/([^/]+))?$#', $path, $m)) {
        wp_safe_redirect(dnz_fit_section_url('dnz_program') . (!empty($m[1]) ? sanitize_title($m[1]) . '/' : ''), 301);
        exit;
    }
}
add_action('template_redirect', 'dnz_fit_old_urls');
