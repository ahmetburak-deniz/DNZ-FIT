<?php get_header(); ?>
<?php while (have_posts()) : the_post();
    $id    = get_the_ID();
    $role  = dnz_fit_meta($id, 'role');
    $spec  = dnz_fit_meta($id, 'specialty');
    $exp   = dnz_fit_meta($id, 'experience');
    $certs = dnz_fit_lines(dnz_fit_meta($id, 'certs'));
    $avail = dnz_fit_meta($id, 'availability');
    $price = dnz_fit_meta($id, 'price');
    $programs = get_posts(array(
        'post_type' => 'dnz_program', 'numberposts' => -1, 'post_status' => 'publish',
        'meta_query' => array(array('key' => '_dnz_coaches', 'value' => '"' . $id . '"', 'compare' => 'LIKE')),
    ));
?>
<section class="page-hero"><div class="wrap">
  <?php echo dnz_fit_t('dnz_fit_coach_eyebrow', 'div', 'eyebrow'); ?>
  <h1><?php the_title(); echo dnz_fit_edit_link($id); ?></h1>
  <?php if ($role || $spec) : ?><p><?php echo esc_html(implode(' · ', array_filter(array($role, $spec)))); ?></p><?php endif; ?>
</div></section>

<main class="wrap section">
  <div class="profile-grid">
    <aside>
      <div class="profile-photo"><?php echo dnz_fit_photo($id, dnz_fit_initials(get_the_title())); echo dnz_fit_photo_btn($id); ?></div>
      <div class="info-card"><ul class="info-list">
        <?php if ($role) : ?><li><span>Unvan</span><b><?php echo esc_html($role); ?></b></li><?php endif; ?>
        <?php if ($spec) : ?><li><span>Uzmanlık</span><b><?php echo esc_html($spec); ?></b></li><?php endif; ?>
        <?php if ($exp !== '' && $exp !== false) : ?><li><span>Deneyim</span><b><?php echo esc_html($exp); ?> yıl</b></li><?php endif; ?>
        <?php if ($price !== '') : ?><li><span>Seans ücreti</span><b><?php echo esc_html(dnz_fit_money($price)); ?></b></li><?php endif; ?>
        <?php if ($avail) : ?><li><span>Müsaitlik</span><b><?php echo nl2br(esc_html($avail)); ?></b></li><?php endif; ?>
      </ul></div>
      <p><a class="btn" href="#talep"><?php echo dnz_fit_t('dnz_fit_coach_btn'); ?></a></p>
    </aside>

    <div class="prose">
      <?php echo dnz_fit_t('dnz_fit_coach_about', 'h2'); ?>
      <?php the_content(); ?>
      <?php echo dnz_fit_gallery($id); ?>
      <?php if ($certs) : ?>
        <?php echo dnz_fit_t('dnz_fit_coach_certs', 'h2'); ?>
        <ul class="check-list"><?php foreach ($certs as $c) echo '<li>' . esc_html($c) . '</li>'; ?></ul>
      <?php endif; ?>
      <?php if ($programs) : ?>
        <?php echo dnz_fit_t('dnz_fit_coach_programs', 'h2'); ?>
        <div class="grid two"><?php foreach ($programs as $p) echo dnz_fit_card($p->ID); ?></div>
      <?php endif; ?>
    </div>
  </div>

  <section class="booking">
    <div class="eyebrow">Randevu</div>
    <h2><?php the_title(); ?> ile randevu talebi</h2>
    <?php echo do_shortcode('[dnz_fit_reservation_form kind="coach" coach="' . (int) $id . '"]'); ?>
  </section>
</main>
<?php endwhile; ?>
<?php get_footer(); ?>
