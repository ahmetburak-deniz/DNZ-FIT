<?php
/* Template Name: Rezervasyon Sayfası */
get_header(); ?>
<section class="page-hero"><?php echo dnz_fit_img_box('dnz_fit_img_res'); ?><div class="wrap">
  <?php echo dnz_fit_t('dnz_fit_page_res_eyebrow', 'div', 'eyebrow'); ?>
  <?php echo dnz_fit_t('dnz_fit_page_res_title', 'h1'); ?>
  <?php echo dnz_fit_t('dnz_fit_page_res_text', 'p'); ?>
</div></section>
<main class="wrap section">
  <div class="res-layout">
    <div><?php while (have_posts()) : the_post(); the_content(); endwhile; ?></div>
    <aside class="side-card">
      <?php echo dnz_fit_t('dnz_fit_res_side_title', 'h3'); ?>
      <ol><?php echo dnz_fit_t('dnz_fit_res_step1', 'li'); echo dnz_fit_t('dnz_fit_res_step2', 'li'); echo dnz_fit_t('dnz_fit_res_step3', 'li'); ?></ol>
      <p><a href="<?php echo esc_url(dnz_fit_section_url('dnz_coach')); ?>">Antrenörleri incele ↗</a></p>
      <p><a href="<?php echo esc_url(dnz_fit_section_url('dnz_program')); ?>">Dersleri incele ↗</a></p>
      <p><a href="<?php echo esc_url(dnz_fit_section_url('dnz_hall')); ?>">Salonları incele ↗</a></p>
      <p><a href="<?php echo esc_url(home_url('/uyelik/')); ?>">Üyelik paketleri ↗</a></p>
    </aside>
  </div>
</main>
<?php get_footer(); ?>
