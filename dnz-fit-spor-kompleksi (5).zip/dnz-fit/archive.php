<?php get_header();
$is_cpt = is_post_type_archive(array('dnz_coach', 'dnz_program', 'dnz_hall'));
$intro = array(
    'dnz_coach'   => 'Antrenörlerimizin uzmanlık alanlarını, özgeçmişlerini ve belgelerini incele; kendine uygun olandan randevu al.',
    'dnz_program' => 'Bireysel ve grup derslerini incele; ücret, gün ve saat bilgilerine bak, kayıt talebi oluştur.',
    'dnz_hall'    => 'Basketbol ve voleybol salonlarımızı incele; hakem hizmeti dahil kiralama talebi oluştur.',
);
$pt = get_post_type();
?>
<section class="page-hero"><div class="wrap">
  <div class="eyebrow">DNZ FİT</div>
  <h1><?php echo esc_html($is_cpt ? post_type_archive_title('', false) : wp_strip_all_tags(get_the_archive_title())); ?></h1>
  <?php if ($is_cpt && isset($intro[$pt])) : ?><p><?php echo esc_html($intro[$pt]); ?></p><?php endif; ?>
</div></section>
<main class="wrap section">
  <div class="grid">
  <?php if (have_posts()) : while (have_posts()) : the_post(); echo dnz_fit_card(get_the_ID()); endwhile; else : ?>
    <p>Henüz içerik eklenmedi.</p>
  <?php endif; ?>
  </div>
  <div class="pagination"><?php the_posts_pagination(); ?></div>
  <?php if ($is_cpt) : ?>
  <div class="band" style="margin-top:30px"><div><h2>Randevu veya rezervasyon mu istiyorsun?</h2><p>Talebini gönder, ekibimiz müsaitliği teyit edip seninle iletişime geçsin.</p></div><a class="btn dark" href="<?php echo esc_url(home_url('/rezervasyon/')); ?>">Talep oluştur ↗</a></div>
  <?php endif; ?>
</main>
<?php get_footer(); ?>
