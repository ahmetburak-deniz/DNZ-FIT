<?php get_header(); ?>
<?php while (have_posts()) : the_post();
    $id       = get_the_ID();
    $type     = dnz_fit_meta($id, 'type');
    $sessions = dnz_fit_meta($id, 'sessions');
    $duration = dnz_fit_meta($id, 'duration');
    $days     = dnz_fit_meta($id, 'days');
    $level    = dnz_fit_meta($id, 'level');
    $capacity = dnz_fit_meta($id, 'capacity');
    $coach_ids = dnz_fit_meta($id, 'coaches');
    $coaches  = (is_array($coach_ids) && $coach_ids) ? get_posts(array('post_type' => 'dnz_coach', 'post__in' => array_map('absint', $coach_ids), 'orderby' => 'post__in', 'numberposts' => -1, 'post_status' => 'publish')) : array();
?>
<section class="page-hero"><div class="wrap">
  <div class="eyebrow"><?php echo esc_html($type ? $type . ' Ders' : 'Ders'); ?></div>
  <h1><?php the_title(); echo dnz_fit_edit_link($id); ?></h1>
  <?php if (has_excerpt()) : ?><p><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
</div></section>

<main class="wrap section">
  <div class="profile-grid">
    <aside>
      <?php if (has_post_thumbnail() || dnz_fit_frontend_edit()) : ?><div class="profile-photo"><?php echo dnz_fit_photo($id, 'DERS'); echo dnz_fit_photo_btn($id); ?></div><?php endif; ?>
      <div class="info-card"><ul class="info-list">
        <?php if ($type) : ?><li><span>Tür</span><b><?php echo esc_html($type); ?></b></li><?php endif; ?>
        <?php $main_price = dnz_fit_meta($id, 'price'); if ($main_price !== '' || !dnz_fit_price_rows($id)) : ?><li><span>Ücret</span><b><?php echo esc_html(dnz_fit_money($main_price)); ?></b></li><?php endif; ?>
        <?php if ($sessions) : ?><li><span>Paket</span><b><?php echo esc_html($sessions); ?></b></li><?php endif; ?>
        <?php if ($duration) : ?><li><span>Seans süresi</span><b><?php echo esc_html($duration); ?> dk</b></li><?php endif; ?>
        <?php if ($days) : ?><li><span>Gün ve saat</span><b><?php echo esc_html($days); ?></b></li><?php endif; ?>
        <?php if ($level) : ?><li><span>Seviye</span><b><?php echo esc_html($level); ?></b></li><?php endif; ?>
        <?php if ($capacity) : ?><li><span>Kontenjan</span><b><?php echo esc_html($capacity); ?> kişi</b></li><?php endif; ?>
      </ul></div>
      <?php echo dnz_fit_price_table($id, get_permalink($id)); ?>
      <p><a class="btn" href="#talep"><?php echo dnz_fit_t('dnz_fit_program_btn'); ?></a></p>
    </aside>

    <div class="prose">
      <?php echo dnz_fit_t('dnz_fit_program_about', 'h2'); ?>
      <?php the_content(); ?>
      <?php echo dnz_fit_gallery($id); ?>
      <?php if ($coaches) : ?>
        <?php echo dnz_fit_t('dnz_fit_program_coaches', 'h2'); ?>
        <div class="grid two"><?php foreach ($coaches as $c) echo dnz_fit_card($c->ID); ?></div>
      <?php endif; ?>
    </div>
  </div>

  <section class="booking">
    <div class="eyebrow">Kayıt</div>
    <h2><?php the_title(); ?> için talep oluştur</h2>
    <?php echo do_shortcode('[dnz_fit_reservation_form kind="program" program="' . (int) $id . '"]'); ?>
  </section>
</main>
<?php endwhile; ?>
<?php get_footer(); ?>
