<?php get_header(); ?>
<?php while (have_posts()) : the_post();
    $id       = get_the_ID();
    $sport    = dnz_fit_meta($id, 'sport');
    $capacity = dnz_fit_meta($id, 'capacity');
    $price    = dnz_fit_meta($id, 'price');
    $referee  = dnz_fit_meta($id, 'referee_price');
    $hours    = dnz_fit_meta($id, 'hours');
    $features = dnz_fit_lines(dnz_fit_meta($id, 'features'));
?>
<section class="page-hero"><div class="wrap">
  <div class="eyebrow"><?php echo esc_html($sport ? $sport . ' Salonu' : 'Spor Salonu'); ?></div>
  <h1><?php the_title(); echo dnz_fit_edit_link($id); ?></h1>
  <?php if (has_excerpt()) : ?><p><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
</div></section>

<main class="wrap section">
  <div class="profile-grid">
    <aside>
      <div class="profile-photo"><?php echo dnz_fit_photo($id, dnz_fit_upper($sport ?: 'SALON')); echo dnz_fit_photo_btn($id); ?></div>
      <div class="info-card"><ul class="info-list">
        <?php if ($sport) : ?><li><span>Spor türü</span><b><?php echo esc_html($sport); ?></b></li><?php endif; ?>
        <?php if ($capacity) : ?><li><span>Kapasite</span><b><?php echo esc_html($capacity); ?> kişi</b></li><?php endif; ?>
        <li><span>Saatlik ücret</span><b><?php echo esc_html(dnz_fit_money($price)); ?></b></li>
        <?php if ($referee !== '') : ?><li><span>Hakem hizmeti</span><b><?php echo esc_html(dnz_fit_money($referee)); ?></b></li><?php endif; ?>
        <?php if ($hours) : ?><li><span>Çalışma saatleri</span><b><?php echo esc_html($hours); ?></b></li><?php endif; ?>
      </ul></div>
      <p><a class="btn" href="#talep"><?php echo dnz_fit_t('dnz_fit_hall_btn'); ?></a></p>
    </aside>

    <div class="prose">
      <?php echo dnz_fit_t('dnz_fit_hall_about', 'h2'); ?>
      <?php the_content(); ?>
      <?php echo dnz_fit_gallery($id); ?>
      <?php if ($features) : ?>
        <?php echo dnz_fit_t('dnz_fit_hall_features', 'h2'); ?>
        <ul class="check-list"><?php foreach ($features as $f) echo '<li>' . esc_html($f) . '</li>'; ?></ul>
      <?php endif; ?>
    </div>
  </div>

  <section class="booking">
    <div class="eyebrow">Rezervasyon</div>
    <h2><?php the_title(); ?> kiralama talebi</h2>
    <?php echo do_shortcode('[dnz_fit_reservation_form kind="hall" hall="' . (int) $id . '"]'); ?>
  </section>
</main>
<?php endwhile; ?>
<?php get_footer(); ?>
