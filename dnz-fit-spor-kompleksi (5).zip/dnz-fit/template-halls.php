<?php
/* Template Name: Salonlar Sayfası */
get_header(); ?>
<section class="page-hero"><?php echo dnz_fit_img_box('dnz_fit_img_halls'); ?><div class="wrap">
  <?php echo dnz_fit_t('dnz_fit_page_halls_eyebrow', 'div', 'eyebrow'); ?>
  <h1><?php the_title(); echo dnz_fit_edit_link(get_queried_object_id()); ?></h1>
</div></section>
<main class="wrap section">
  <?php while (have_posts()) : the_post(); if (trim(get_the_content())) : ?><div class="lead section-intro"><?php the_content(); ?></div><?php endif; endwhile; ?>
  <?php dnz_fit_listing('dnz_hall', 'sport', ' salonları'); ?>
  <?php echo dnz_fit_band('dnz_fit_page_halls_band_title', 'dnz_fit_page_halls_band_text', 'dnz_fit_page_halls_band_btn', home_url('/rezervasyon/?kind=hall')); ?>
</main>
<?php get_footer(); ?>
