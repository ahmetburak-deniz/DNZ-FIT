<?php
if (!defined('ABSPATH')) exit;
define('DNZ_FIT_VERSION', '3.4.0');

function dnz_fit_setup_theme() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    register_nav_menus(array('primary' => __('Ana Menü', 'dnz-fit')));
}
add_action('after_setup_theme', 'dnz_fit_setup_theme');

function dnz_fit_assets() {
    wp_enqueue_style('dnz-fit-style', get_stylesheet_uri(), array(), DNZ_FIT_VERSION);
}
add_action('wp_enqueue_scripts', 'dnz_fit_assets');

require_once get_template_directory() . '/inc/helpers.php';
require_once get_template_directory() . '/inc/post-types.php';
require_once get_template_directory() . '/inc/meta.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/media-prices.php';
require_once get_template_directory() . '/inc/frontend-edit.php';
require_once get_template_directory() . '/inc/forms.php';
require_once get_template_directory() . '/inc/setup.php';
