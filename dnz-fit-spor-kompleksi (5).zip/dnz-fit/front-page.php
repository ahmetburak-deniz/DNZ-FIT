<?php get_header();
$programs = get_posts(array('post_type' => 'dnz_program', 'numberposts' => 3, 'post_status' => 'publish'));
$coaches  = get_posts(array('post_type' => 'dnz_coach', 'numberposts' => 3, 'post_status' => 'publish'));
$halls    = get_posts(array('post_type' => 'dnz_hall', 'numberposts' => 3, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC'));
$plans    = get_posts(array('post_type' => 'dnz_plan', 'numberposts' => 3, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC'));
?>
<main>
<section class="hero"><div class="wrap hero-grid"><div>
  <?php echo dnz_fit_t('dnz_fit_hero_eyebrow', 'div', 'eyebrow'); ?>
  <?php echo dnz_fit_t('dnz_fit_hero_title', 'h1'); ?>
  <?php echo dnz_fit_t('dnz_fit_hero_text', 'p'); ?>
  <a class="btn" href="<?php echo esc_url(home_url('/rezervasyon/')); ?>"><?php echo dnz_fit_t('dnz_fit_hero_btn1'); ?></a>
  <a class="btn dark" href="<?php echo esc_url(home_url('/uyelik/')); ?>"><?php echo dnz_fit_t('dnz_fit_hero_btn2'); ?></a>
</div><?php echo dnz_fit_hero_graphic(); ?></div></section>

<section class="section" id="pt-egitimleri"><div class="wrap">
  <?php echo dnz_fit_head('home_programs'); ?>
  <div class="grid">
  <?php if ($programs) : foreach ($programs as $p) echo dnz_fit_card($p->ID); echo dnz_fit_add_card('dnz_program'); else : ?>
    <article class="card"><div class="card-art">DERS</div><div class="card-body"><h3>Ders ekle</h3><p>Panelde Dersler → Yeni Ders Ekle bölümünden ders sayfalarını oluştur.</p></div></article>
  <?php endif; ?>
  </div>
  <p><a class="btn" href="<?php echo esc_url(dnz_fit_section_url('dnz_program')); ?>"><?php echo dnz_fit_t('dnz_fit_home_programs_btn'); ?></a></p>
</div></section>

<section class="section" id="antrenorler"><div class="wrap">
  <?php echo dnz_fit_head('home_coaches'); ?>
  <div class="grid">
  <?php if ($coaches) : foreach ($coaches as $c) echo dnz_fit_card($c->ID); echo dnz_fit_add_card('dnz_coach'); else : ?>
    <article class="card"><div class="card-art">PT</div><div class="card-body"><h3>Antrenör profili ekle</h3><p>Panelde Antrenörler → Yeni Antrenör Ekle bölümünden isim, uzmanlık, özgeçmiş ve belgeleri gir.</p></div></article>
  <?php endif; ?>
  </div>
  <p><a class="btn" href="<?php echo esc_url(dnz_fit_section_url('dnz_coach')); ?>"><?php echo dnz_fit_t('dnz_fit_home_coaches_btn'); ?></a></p>
</div></section>

<section class="section" id="salonlar"><div class="wrap">
  <?php echo dnz_fit_head('home_halls'); ?>
  <div class="grid">
  <?php if ($halls) : foreach ($halls as $h) echo dnz_fit_card($h->ID); echo dnz_fit_add_card('dnz_hall'); else : ?>
    <article class="card"><div class="card-art">BASKET 01</div><div class="card-body"><span class="pill">Basketbol</span><h3>Basketbol Salonu 1</h3></div></article>
    <article class="card"><div class="card-art">BASKET 02</div><div class="card-body"><span class="pill">Basketbol</span><h3>Basketbol Salonu 2</h3></div></article>
    <article class="card"><div class="card-art">VOLEYBOL</div><div class="card-body"><span class="pill">Voleybol</span><h3>Voleybol Salonu 1</h3></div></article>
  <?php endif; ?>
  </div>
  <a class="btn" href="<?php echo esc_url(home_url('/rezervasyon/?kind=hall')); ?>"><?php echo dnz_fit_t('dnz_fit_home_halls_btn'); ?></a>
</div></section>

<section class="section" id="tesis"><div class="wrap">
  <?php echo dnz_fit_head('home_facility'); ?>
  <div class="feature-list">
  <?php foreach (range(1, 4) as $n) {
      echo '<div class="feature">' . dnz_fit_img_box('dnz_fit_feat' . $n . '_img') . dnz_fit_t('dnz_fit_feat' . $n . '_icon', 'span') . dnz_fit_t('dnz_fit_feat' . $n . '_title', 'b') . dnz_fit_t('dnz_fit_feat' . $n . '_desc', 'small') . '</div>';
  } ?>
  </div>
</div></section>

<section class="section" id="uyelik"><div class="wrap">
  <?php echo dnz_fit_head('home_plans'); ?>
  <?php if ($plans || dnz_fit_frontend_edit()) : ?>
  <div class="plans">
    <?php foreach ($plans as $p) echo dnz_fit_plan_card($p, home_url('/uyelik/')); echo dnz_fit_add_card('dnz_plan'); ?>
  </div>
  <?php endif; ?>
  <?php echo dnz_fit_band('dnz_fit_home_plans_band_title', 'dnz_fit_contact_text', 'dnz_fit_home_plans_band_btn', home_url('/uyelik/'), false); ?>
</div></section>

<section class="section"><div class="wrap">
  <?php echo dnz_fit_head('home_blog'); ?>
  <div class="grid">
  <?php $posts = get_posts(array('post_type' => 'post', 'numberposts' => 3, 'post_status' => 'publish'));
  if ($posts) : foreach ($posts as $p) echo dnz_fit_card($p->ID); else : ?>
    <article class="card"><div class="card-art">NEWS</div><div class="card-body"><h3>İlk duyurunu yayınla</h3><p>WordPress panelinde Yazılar → Yeni yazı ekle yolunu izle.</p></div></article>
  <?php endif; ?>
  </div>
</div></section>
</main>
<?php get_footer(); ?>
